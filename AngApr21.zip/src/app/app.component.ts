import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'AngApr21';

  formData!:FormGroup;
  submit:boolean = false;
  constructor(private refForm:FormBuilder){}

  ngOnInit(): void {
    this.formData = this.refForm.group({
      userName: ['', Validators.required],
      emailId: ['',Validators.required, Validators.email],
      phnNo: ['',Validators.required, Validators.minLength(10), Validators.maxLength(10)]
    })
  }

  onSubmit(){
    this.submit = true;
    if(this.formData.valid){
      alert("Form Data Validated Successfully.")
    }
  }
}
