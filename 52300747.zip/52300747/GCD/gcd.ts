function Gcd(num1:number, num2: number) : number {
    if(num2 === 0){
        return num1
    } 
    return Gcd(num2, num1%num2)
}

var num1: number = 12, num2 : number = 9;
const res: number = Gcd(num1, num2);
console.log(`GCD of ${num1} , ${num2} is ${res}`);