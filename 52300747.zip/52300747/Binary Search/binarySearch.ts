function binaryAlg(arr: number[], target: number, low: number = 0, high: number = arr.length - 1): number {
    if (low > high) {
        return -1;
    }
    const mid: number = Math.floor((low + high) / 2);
    if (arr[mid] === target) {
        return mid;
    } else if (arr[mid] > target) {
        return binaryAlg(arr, target, low, mid - 1);
    } else {
        return binaryAlg(arr, target, mid + 1, high);
    }
}

var array: number[] = [1,2,3,4,5,6,7];
var target: number = 5;

let foundIndex : number = binaryAlg(array, target);

console.log(`Number ${target} found at index ${foundIndex} in array [${array}]`);