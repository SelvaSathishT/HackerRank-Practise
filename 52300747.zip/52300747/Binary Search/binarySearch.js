function binaryAlg(arr, target, low, high) {
    if (low === void 0) { low = 0; }
    if (high === void 0) { high = arr.length - 1; }
    if (low > high) {
        return -1;
    }
    var mid = Math.floor((low + high) / 2);
    if (arr[mid] === target) {
        return mid;
    }
    else if (arr[mid] > target) {
        return binaryAlg(arr, target, low, mid - 1);
    }
    else {
        return binaryAlg(arr, target, mid + 1, high);
    }
}
var array = [1, 2, 3, 4, 5, 6, 7];
var target = 5;
var foundIndex = binaryAlg(array, target);
console.log("Number ".concat(target, " found at index ").concat(foundIndex, " in array [").concat(array, "]"));
