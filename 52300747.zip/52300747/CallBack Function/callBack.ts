function calculate(year: number, callback: (age: number) => void): void {
    const currentYear: number = new Date().getFullYear();
    const age: number = currentYear - year;
    setTimeout(() => {
        callback(age);
    }, 2000);
}

function getAge(): void {
    const year: number = 2001
    calculate(year, (age: number) => {
        console.log(`After 2-sec delay, Age is ${age}`);
    });
}

getAge();