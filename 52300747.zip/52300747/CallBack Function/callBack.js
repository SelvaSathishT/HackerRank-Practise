function calculate(year, callback) {
    var currentYear = new Date().getFullYear();
    var age = currentYear - year;
    setTimeout(function () {
        callback(age);
    }, 2000);
}
function getAge() {
    var year = 2001;
    calculate(year, function (age) {
        console.log("After 2-sec delay, Age is ".concat(age));
    });
}
getAge();
