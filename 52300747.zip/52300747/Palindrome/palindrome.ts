function checkPalindrome (str: string) : string {
    console.log('String : ',str);
    var rev:string = str.split('').reverse().join('');
    if(str === rev){
        return `String ${str} is a Palindrome`;
    } else {
        return `String ${str} is not a Palindrome`;
    }
}

var result : string = checkPalindrome('malayalam');
console.log(result);