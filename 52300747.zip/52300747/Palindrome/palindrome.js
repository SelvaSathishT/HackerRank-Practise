function checkPalindrome(str) {
    console.log('String : ', str);
    var rev = str.split('').reverse().join('');
    if (str === rev) {
        return "String ".concat(str, " is a Palindrome");
    }
    else {
        return "String ".concat(str, " is not a Palindrome");
    }
}
var result = checkPalindrome('malayalam');
console.log(result);
