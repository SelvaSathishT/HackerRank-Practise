function checkArmstrong (num :number) : boolean {
    var temp : number = num, sum : number = 0;
    while(temp>0){
        var digit : number = temp % 10;
        sum = sum + (digit ** 3);
        temp = Math.floor(temp/10)
    };
    if(sum === num){
        return true
    } else {
        return false
    }
}

var num: number = 371;
const result: boolean = checkArmstrong(num);
if(result){
    console.log(`${num} is a Armstrong Number`)
} else {
    console.log(`${num} is not  a Armstrong Number`)
}