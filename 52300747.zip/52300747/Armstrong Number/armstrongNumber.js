function checkArmstrong(num) {
    var temp = num, sum = 0;
    while (temp > 0) {
        var digit = temp % 10;
        sum = sum + (Math.pow(digit, 3));
        temp = Math.floor(temp / 10);
    }
    ;
    if (sum === num) {
        return true;
    }
    else {
        return false;
    }
}
var num = 371;
var result = checkArmstrong(num);
if (result) {
    console.log("".concat(num, " is a Armstrong Number"));
}
else {
    console.log("".concat(num, " is not  a Armstrong Number"));
}
