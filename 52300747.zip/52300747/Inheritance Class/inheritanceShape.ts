class Shape {
    calculateArea(): number {
        return 0;
    }
}

class Circle extends Shape {
    radius: number;

    constructor(radius: number) {
        super();
        this.radius = radius;
    }

    calculateArea(): number {
        return Math.PI * this.radius * this.radius;
    }
}

class Triangle extends Shape {
    base: number;
    height: number;

    constructor(base: number, height: number) {
        super();
        this.base = base;
        this.height = height;
    }

    calculateArea(): number {
        return 0.5 * this.base * this.height;
    }
}

function shapeArea(): void {
    
    const radius: number = 5;
    const base: number = 10;
    const height: number = 6;

    // Calculating area for Circle
    const myCircle = new Circle(radius);
    const circleArea = myCircle.calculateArea().toFixed(2);
    console.log(`Area of circle for radius ${radius} is ${circleArea}`);

    // Calculating area for Triangle
    const myTriangle = new Triangle(base, height);
    const triangleArea = myTriangle.calculateArea();
    console.log(`Area of triangle for (Base: ${base} & Height: ${height}) is ${triangleArea}`);
}

shapeArea();