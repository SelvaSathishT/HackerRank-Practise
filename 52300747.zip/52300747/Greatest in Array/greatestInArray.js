function getLargest(arr) {
    var larArr = [];
    for (var i = 0; i < arr.length; i++) {
        var ascend = arr[i].sort(function (a, b) { return b - a; });
        larArr.push(ascend[0]);
    }
    console.log("Largest numbers in each array", larArr);
}
getLargest([[1, 2, 3], [9, 8, 7], [11, 23, 5]]);
