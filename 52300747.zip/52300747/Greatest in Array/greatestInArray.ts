function getLargest(arr : number[][]):void {
    var larArr: number[] = [];
    for(let i:number = 0; i<arr.length ;i++){
        const ascend : number[] = arr[i].sort((a,b) => b-a);
        larArr.push(ascend[0])
    }
    console.log(`Largest numbers in each array`, larArr);
}

getLargest([[1,2,3],[9,8,7],[11,23,5]])