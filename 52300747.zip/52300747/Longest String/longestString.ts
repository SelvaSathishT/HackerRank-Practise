function checkLongest(str: string) : void {
    var len: number = 0;
    var longestStr: string = "";
    var arr :string[] = str.split(' ');
    //console.log('str=>',str,"arr=>",arr);
    for(var i:number = 0 ; i<arr.length ; i++){
        if(len < Number(arr[i].length)){
            console.log('greater than length')
            len = arr[i].length;
            longestStr = arr[i]
        }
    }
    console.log(`Longest String is ${longestStr} with length ${len}`);
}

checkLongest('Checking the longest string from this');