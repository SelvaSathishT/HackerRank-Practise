function checkLongest(str) {
    var len = 0;
    var longestStr = "";
    var arr = str.split(' ');
    //console.log('str=>',str,"arr=>",arr);
    for (var i = 0; i < arr.length; i++) {
        if (len < Number(arr[i].length)) {
            console.log('greater than length');
            len = arr[i].length;
            longestStr = arr[i];
        }
    }
    console.log("Longest String is ".concat(longestStr, " with length ").concat(len));
}
checkLongest('Checking the longest string from this');
