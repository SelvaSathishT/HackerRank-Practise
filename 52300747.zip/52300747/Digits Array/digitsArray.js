function digitsArray(num) {
    var result = [];
    while (num > 0) {
        var digit = num % 10;
        result.push(digit);
        num = Math.floor(num / 10);
    }
    console.log('Digits Array =>', result);
}
digitsArray(52300747);
