function digitsArray (num: number) : void {
    var result : number[] = [];
    while(num>0){
        var digit : number = num%10;
        result.push(digit);
        num = Math.floor(num/10);
    }
    console.log('Digits Array =>',result);
}

digitsArray(52300747)