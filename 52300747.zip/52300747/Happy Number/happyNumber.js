var happy_numbers = [];
var step = [];
function calculateHappyNumbers(n) {
    try {
        var input_number = String(n);
        var result = 0;
        step.push(input_number);
        for (var i = 0; i < input_number.length; i++) {
            result += Math.pow(Number(input_number[i]), 2);
        }
        if (result !== 1) {
            return calculateHappyNumbers(result);
        }
        else {
            happy_numbers.push(Number(step[0]));
            return Number(step[0]);
        }
    }
    catch (error) {
        console.log(error);
        return undefined;
    }
}
for (var j = 1; j < 30; j++) {
    //console.log(calculateHappyNumbers(j));
    step = [];
}
for (var k = 0; k < 5; k++) {
    console.log(happy_numbers[k]);
}
