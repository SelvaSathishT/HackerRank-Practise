let happy_numbers: number[] = [];
let step: string[] = [];

function calculateHappyNumbers(n: number): number | undefined {
    try {
        let input_number: string = String(n);
        let result: number = 0;
        step.push(input_number);
        for (let i = 0; i < input_number.length; i++) {
            result += Math.pow(Number(input_number[i]), 2);
        }
        if (result !== 1) {
            return calculateHappyNumbers(result);
        } else {
            happy_numbers.push(Number(step[0]));
            return Number(step[0]);
        }
    } catch (error) {
        console.log(error);
        return undefined;
    }
}

for (let j = 1; j < 30; j++) {
    //console.log(calculateHappyNumbers(j));
    step = [];
}

for (let k = 0; k < 5; k++) {
    console.log(happy_numbers[k]);
}