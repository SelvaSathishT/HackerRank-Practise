function demo( str : string) : void {
    console.log(`String : ${str}`);
    var reversed : string = str.split(' ').reverse().join(' ');
    console.log(`Reversed String : ${reversed}`)
}

demo('Welcome to HCLTech');