function demo(str) {
    console.log("String : ".concat(str));
    var reversed = str.split(' ').reverse().join(' ');
    console.log("Reversed String : ".concat(reversed));
}
demo('Welcome to HCLTech');
