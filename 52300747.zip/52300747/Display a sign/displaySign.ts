function chechSign(num1:number, num2: number, num3:number){
    var result:number = num1 * num2 * num3;
    if(result > 0){
        console.log(`The sign is +`);
    } else {
        console.log('The sign is -')
    }
}

chechSign(3,-7,2);