function chechSign(num1, num2, num3) {
    var result = num1 * num2 * num3;
    if (result > 0) {
        console.log("The sign is +");
    }
    else {
        console.log('The sign is -');
    }
}
chechSign(3, -7, 2);
