var Rectangle = /** @class */ (function () {
    function Rectangle(width, height) {
        this.width = width;
        this.height = height;
    }
    Rectangle.prototype.area = function () {
        return this.width * this.height;
    };
    Rectangle.prototype.perimeter = function () {
        return 2 * (this.width + this.height);
    };
    return Rectangle;
}());
function calcRectangle() {
    var width = 10;
    var height = 5;
    console.log("calc=>", width, height);
    var myInstance = new Rectangle(width, height);
    var area = myInstance.area();
    var perimeter = myInstance.perimeter();
    console.log("Rectangle of (W:".concat(width, " H:").concat(height, ") has Area = ").concat(area, ", Perimeter = ").concat(perimeter));
}
calcRectangle();
