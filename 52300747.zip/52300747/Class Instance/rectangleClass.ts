class Rectangle {
    width: number;
    height: number;

    constructor(width: number, height: number) {
        this.width = width;
        this.height = height;
    }

    area(): number {
        return this.width * this.height;
    }

    perimeter(): number {
        return 2 * (this.width + this.height);
    }
}

function calcRectangle(): void {
    const width: number = 10; 
    const height: number = 5; 
    console.log("calc=>", width, height);
    const myInstance = new Rectangle(width, height);
    const area = myInstance.area();
    const perimeter = myInstance.perimeter();
    console.log(`Rectangle of (W:${width} H:${height}) has Area = ${area}, Perimeter = ${perimeter}`);
}

calcRectangle();