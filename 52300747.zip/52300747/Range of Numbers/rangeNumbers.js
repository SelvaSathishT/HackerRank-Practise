function generateArray(num1, num2) {
    var arr = [];
    for (var i = num1 + 1; i < num2; i++) {
        arr.push(i);
    }
    return arr;
}
var num1 = 2, num2 = 9;
var range = generateArray(num1, num2);
console.log("Range of Array between (".concat(num1, ",").concat(num2, ") is [").concat(range, "]"));
