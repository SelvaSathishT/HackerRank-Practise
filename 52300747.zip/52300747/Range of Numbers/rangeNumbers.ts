function generateArray (num1: number, num2: number) : any {
    let arr: number[] = [];
    for(let i:number =num1+1 ;i <num2; i++){
        arr.push(i)
    }
    return arr;
}

var num1 : number = 2, num2 : number = 9;
var range: number[] = generateArray(num1, num2);

console.log(`Range of Array between (${num1},${num2}) is [${range}]`);
