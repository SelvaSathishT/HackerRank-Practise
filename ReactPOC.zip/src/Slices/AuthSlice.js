import { createSlice } from "@reduxjs/toolkit";
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

export const authSlice = createSlice({
  name: "auth",
  initialState: {
    name: "",
    email: "",
    data: {},
  },
  reducers: {
    login: (state, action) => {
      state.name = action.payload.name;
      state.email = action.payload.email;
      state.data = action.payload.data;

    },
    logout: (state) => {
        state.name = "";
        state.email = "";
        state.data = {};
    },
  },
});

// Action creators are generated for each case reducer function
export const { login, logout } = authSlice.actions;

const persistConfig = {
    key: 'auth',
    storage ,
  };

export const authReducer = persistReducer(persistConfig, authSlice.reducer);



