import { createSlice } from "@reduxjs/toolkit";
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

export const usersSlice = createSlice({
  name: "users",
  initialState: {
    users: []
  },
  reducers: {
    register: (state, action) => {
      state.users.push(action.payload);
    },
    clearUsers: (state) => {
      state.users = []
    }
  },
});

// Action creators are generated for each case reducer function
export const { register, clearUsers } = usersSlice.actions;

const persistConfig = {
    key: 'users',
    storage ,
  };

export const usersReducer = persistReducer(persistConfig, usersSlice.reducer);



