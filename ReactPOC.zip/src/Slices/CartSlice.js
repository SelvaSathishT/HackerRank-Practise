import { createSlice } from "@reduxjs/toolkit";
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

export const cartSlice = createSlice({
  name: "cart",
  initialState: {
    carts: []
  },
  reducers: {
    addCart: (state, action) => {
      const {userId, value} = action.payload;
      console.log('slice=>',action.payload, userId, value);
      let user = state.carts.find((u) => u.id === userId);
      if(user){
        user.cart.push(value);
      } else {
        user = {id: userId, cart: [value]};
        state.carts.push(user);
      }

    },
    removeCart: (state, action) => {
        const {userId, item} = action.payload;
        console.log('remove slice=>',action.payload , userId, item)
        const user = state.carts.find((u) => u.id === userId);
      console.log('found user =>',user.cart)
      if(user){
        user.cart = user.cart.filter(cart => cart.id !== item.id || cart.name !== item.name)
      }
    },
    clearCart: (state) => {
        state.carts = []
    },
  },
});

// Action creators are generated for each case reducer function
export const { addCart, removeCart, clearCart } = cartSlice.actions;

const persistConfig = {
    key: 'cart',
    storage ,
  };

export const cartReducer = persistReducer(persistConfig, cartSlice.reducer);

