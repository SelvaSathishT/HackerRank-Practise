import "./App.css";
import { BrowserRouter } from "react-router-dom";
import RoutesPage from "./Routes/Routes";
import { MyProvider } from "./Datacontext";

function App() {
  return (
    <div className="App">
      <MyProvider>
        <BrowserRouter>
          <RoutesPage />
        </BrowserRouter>
      </MyProvider>
    </div>
  );
}

export default App;