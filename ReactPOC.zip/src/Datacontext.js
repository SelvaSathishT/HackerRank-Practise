import React, { createContext, useState } from "react";

// Create a Context
const DataContext = createContext();

// Create a provider component
const MyProvider = ({ children }) => {
  const [state, setState] = useState("Hello, World!");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedBrand, setSelectedBrand] = useState("");

  return (
    <DataContext.Provider
      value={{
        state,
        setState,
        selectedBrand,
        setSelectedBrand,
        selectedCategory,
        setSelectedCategory,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export { DataContext, MyProvider };
