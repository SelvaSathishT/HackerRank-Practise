import React, { useContext, useEffect } from 'react'
import Navbar from './Home/Navbar';
import Footer from './Home/Footer';
import { useNavigate } from 'react-router-dom';
import { DataContext } from '../Datacontext';

const Categories = ({allProducts}) => {
  let navigate = useNavigate();
  const {setSelectedCategory, setSelectedBrand} = useContext(DataContext);
    
    useEffect(() => {
        window.scrollTo(0, 0);
      }, []);

    const categories = [...new Set(allProducts.map((p)=> p.category))]; 

    const handleCategoryClick = (category) => {
      console.log('category=>',category);
      setSelectedCategory(category);
      setSelectedBrand('');
      navigate('/products');
    }

  return (
    <div>
      <Navbar />
      <div className='w-full p-10'>
        <h1 className='text-2xl text-start font-bold'>All Categories</h1>
        <div className='grid  md:grid-cols-4 sm:grid-cols-2 gap-3 p-3'>
            {categories.map((category,index)=>(
                  <div onClick={() => handleCategoryClick(category)} className='border-1 shadow-lg border-gray-300 font-l m-8 flex items-center justify-center h-20 rounded-lg cursor-pointer'>
                  {category}
                  </div>
            ))}
            </div>
      </div>
      <Footer />
    </div>
  )
}

export default Categories;
