import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { clearCart, removeCart } from '../Slices/CartSlice';
import Navbar from './Home/Navbar';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormHelperText,
  Button,
} from "@mui/material";
import { useNavigate } from 'react-router-dom';
import { clearUsers } from '../Slices/UsersSlice';

const Cart = () => {
  let navigate = useNavigate();
    const dispatch = useDispatch();
    const userId = useSelector(state => state.auth.data.id);
    const userName = useSelector(state => state.auth.name);
    const userCart = useSelector(state => state.carts.carts.find(u => u.id === userId) || {}) ;
    const [totalAmt, setTotalAmt] = useState(0);
    const [selectedItem, setSelectedItem] = useState(null);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [hasCart, setHasCart] = useState(false);
    const [buyDialog, setBuyDialog] = useState(false);
    
    // const totalAmt = userCart

    const calculateTotalPrice = (cart) =>{
      return cart.reduce((sum,item) => sum + Number(item.price) * Number(item.quantity) , 0);
    }

    useEffect(()=>{
      if(Object.keys(userCart).length !== 0){
        const total = calculateTotalPrice(userCart.cart)
        console.log('total=>',total);
        setTotalAmt(total);
      }
    },[userCart])
    

    const handleClearCart = ()=>{
         console.log('cart =>',userCart);
         
        //dispatch(clearCart());
    }

    const showEditDialog =(value) => {
      setSelectedItem(value);
    setDialogOpen(true);
    }
    //pass@123
    const closeCartDialog = () => {
      setSelectedItem(null);
      setDialogOpen(false);
    };

    const removeItem = () => {
      dispatch(removeCart({userId, item: selectedItem}));
      setSelectedItem(null);
      setDialogOpen(false);
      //console.log('after remove=>',userCart);
    }

    const navigateCategories = () => {
      //console.log('products...');
      navigate('/categories');
    }

    const proceedBuy = () => {
      setBuyDialog(true);
    }

    const closeBuyDialog = () => {
      setBuyDialog(false);
    }

    const clearRedux = () => {
      dispatch(clearUsers());
      dispatch(clearCart());
    }
    useEffect(()=>{
      console.log('cart=>',userCart.cart);
      if(userCart.cart && userCart.cart.length !== 0){
        setHasCart(true);
      }
      //pass@123
    },[selectedItem])

  return (
    <div>
        <Navbar />
      <div className='w-full p-10 flex flex-col items-start'>
        <h3 className='font-bold text-2xl mb-3'>Hii {userName}!</h3>
        {hasCart ? <div>
          <p className='text-xl'>Your Cart...</p>
      {userCart.cart.map((item,index)=>(
        <div key={index} className='w-[70%] ml-50 sm:w-full border-2 m-2 flex flex-row justify-between px-2' onClick={() => showEditDialog(item)}>
            <img src={item.image} className='w-20 h-20'/>
            <div>
            <h2>{item.name}</h2>
            <div className='flex flex-row'>
                <p className=''>Category: {item.category}</p>
                <p>Brand: {item.brand}</p>
            </div>

            </div>
            <div>
            <p>₹{item.price}</p>
            <p>Quantity: {item.quantity || 1}</p>
            </div>
        </div>
      ))}
      <div className='w-full ml-50 flex justify-between'>
        <p>Total Amount: {totalAmt}</p>
        <button className='border-1 p-2 rounded cursor-pointer' onClick={proceedBuy}>Proceed To Buy</button>
      </div>
        </div> : 
        <div className='w-full flex flex-col justify-center items-center h-54vh gap-3'>
          <p>No items in cart</p>
          <div className='border-1 cursor-pointer p-2 rounded-md' onClick={() => {navigateCategories();}}>Browse items</div>
          </div>}
      
      </div>
      <Dialog
              open={dialogOpen}
              onClose={closeCartDialog}
              sx={{
                "& .MuiDialog-paper": {
                  width: "500px",
                },
              }}
            >
              <DialogTitle>Item Details</DialogTitle>
              <DialogContent>
                {selectedItem && (
                  <div className="border-1 flex flex-row ">
                    <img src={selectedItem.image} className="w-20 h-20" />
                    <div className="w-full p-2">
                    <p>{selectedItem.name}</p>
                    <div className="flex flex-row gap-2">
                    <p>₹ {selectedItem.price}</p>
                    <p>Quantity: {selectedItem.quantity}</p>
                    
      
                    </div>
                    </div>
                  </div>
                )}
              </DialogContent>
              <DialogActions>
                <Button onClick={closeCartDialog} variant="outlined" color="error">
                  Cancel
                </Button>
                <Button onClick={removeItem} variant="contained" color="primary">
                  Remove
                </Button>
              </DialogActions>
            </Dialog>

            <Dialog
              open={buyDialog}
              onClose={closeBuyDialog}
              sx={{
                "& .MuiDialog-paper": {
                  width: "500px",
                },
              }}
            >
              <DialogTitle>Delivery</DialogTitle>
              <DialogContent>
                <p>Your Cart items with value {totalAmt} will be delivered soon. Thanks for choosing US!</p>
              </DialogContent>
              <DialogActions>
                <Button onClick={closeBuyDialog} variant="outlined" color="primary">
                  OK
                </Button>
              </DialogActions>
            </Dialog>
    </div>
  )
}

export default Cart
