import React, { useContext, useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { addCart } from '../../Slices/CartSlice';
import Navbar from '../Home/Navbar';
import { DataContext } from '../../Datacontext';

const AllProducts = ({ allProducts }) => {
    let navigate = useNavigate();
    const dispatch = useDispatch();
    const { selectedBrand, setSelectedBrand, selectedCategory, setSelectedCategory } = useContext(DataContext);
    const [selectedItem, setSelectedItem] = useState(null);
    const [cart, setCart] = useState([]);
    const userId = useSelector(state => state.auth.data.id);

    const categories = [...new Set(allProducts.map((p)=> p.category))];
    const brands = [...new Set(allProducts.map((p)=> p.brand))];

    useEffect(() => {
            window.scrollTo(0, 0);
          }, []);

    const filteredProducts = allProducts.filter((product) => {
        return(
            (selectedCategory ? product.category === selectedCategory : true) && 
            (selectedBrand ? product.brand === selectedBrand : true)
        );
    });

    const handleItemClick = (category,item) => {
        //console.log('item =>',item, category);
        navigate(`/item?category=${category.category}&brand=${category.brand}&id=${item.id}`)
    };

//     id:2
// image:"/images/bat.png"
// material:"English Willow"
// name:"MRF Virat Kohli Edition"
// price:320
// weight:"2.9 lbs"
    const addToCart = (category, item) => {
        
        var value = {
            id: item.id,
            name: item.name,
            price: item.price,
            category: category.category,
            brand: category.brand,
            image: item.image,
            item: item,
        }
        selectedItem(value);
        console.log('item=>',userId, value);
        dispatch(addCart({userId, value}));
        setCart((prev) => [...prev,value]);
    }

    const handleBackBtn = () => {
      navigate(-1);
    }

  return (
    <div>
      <Navbar />
    <div className="p-5">
        <div className='sticky top-18 border-2 bg-white'>

      <h2 className="text-2xl font-bold mb-4" onClick={()=>console.log('cart =>',cart)}>Collection</h2>
      <div className='flex px-3 gap-4 mb-5 flex-col sm:flex-row md:flex-row justify-between items-center'>
        <div className='border-1 p-2 rounded-lg cursor-pointer' onClick={handleBackBtn}>
          <p>Back</p>
        </div>
        
        <div className='flex'>

        <p>Filter :-</p>
        <select className='border p-2 rounded' onChange={e => setSelectedCategory(e.target.value)} value={selectedCategory}>
            <option value="">All Categories</option>
            {categories.map((category,index)=>(
                <option key={index} value={category}>{category}</option>
            ))}
        </select>
        <select className='border p-2 rounded' onChange={e => setSelectedBrand(e.target.value)} value={selectedBrand}>
            <option value="">All Brands</option>
            {brands.map((brand,index)=>(
                <option key={index} value={brand}>{brand}</option>
            ))}
        </select>
        </div>
      </div>
        </div>
      {filteredProducts.map((category, index) => (
        <div key={index} className="mb-6">
          <h3 className="text-xl font-semibold mb-2">{category.category || 'Unknown category'}</h3>
          <h3 className="text-xl font-semibold mb-2">{category.brand || 'Unknown Brand'}</h3>
          <div className="grid grid-cols-3 gap-4">
            {Array.isArray(category.items) ? (
              category.items.map((item) => (
                <div key={item.id} className="border p-3 rounded-lg shadow-md " >
                  <h4 className="text-lg font-semibold">{item.name}</h4>
                  <p>₹{item.price}</p>
                  <img src={item.image} alt={item.name} className="w-full h-32 object-contain mt-2" />
                  <button className='mt-2 bg-blue-400 rounded-md cursor-pointer text-white px-3 py-1' onClick={(e) => {e.stopPropagation();handleItemClick(category,item);}}>View</button>
                </div>
              ))
            ) : (
              <p>No items found for this category.</p>
            )}
            {}
          </div>
        </div>
      ))}
    </div>
    </div>
  )
}

export default AllProducts;
