import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { addCart } from "../../Slices/CartSlice";
import { useDispatch, useSelector } from "react-redux";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormHelperText,
  Button,
} from "@mui/material";
import Navbar from "../Home/Navbar";

const SingleProduct = ({ allProducts }) => {
  const location = useLocation();
  const dispatch = useDispatch();
  const userId = useSelector((state) => state.auth.data.id);
  const params = new URLSearchParams(location.search);
  const [selectedItem, setSelectedItem] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const category = params.get("category");
  const brand = params.get("brand");
  const id = params.get("id");
  const values = [1,2,3,4,5,6,7,8,9,10];
  const [quantity, setQuantity] = useState(1);
  const categoryData = allProducts.filter((cat) => cat.category === category);

  const brandData = categoryData.filter((b) => b.brand === brand);

  useEffect(() => {
          window.scrollTo(0, 0);
        }, []);

  const product = brandData
    .flatMap((b) => b.items)
    .find((item) => item.id.toString() === id);
  //console.log("product=>",product);
  //   const similarProducts = categoryData
  //   .flatMap( cat => cat.brand)
  //   .flatMap( b => b.items)
  //   .filter(item => item.id.toString() !== id);

  //console.log('similarProducts=>',similarProducts)
  //   const product = allProducts.find(
  //     (item) =>
  //       item.id === id &&
  //       item.category === category &&
  //       item.brand === brand
  //   );
  useEffect(() => {
    //console.log(allProducts[0]);
  }, []);

  const showCartDialog = () => {
    var value = {
      id: product.id,
      name: product.name,
      price: product.price,
      category: brandData[0].category,
      brand: brandData[0].brand,
      image: product.image,
      item: product,
    };

    setSelectedItem(value);
    setDialogOpen(true);
  };

  const closeCartDialog = () => {
    setSelectedItem(null);
    setDialogOpen(false);
  };

  const addToCart = () => {
    //console.log('prod =>',product, brandData[0].category, brandData[0].brand);
    var value = {
      id: product.id,
      name: product.name,
      price: product.price,
      category: brandData[0].category,
      brand: brandData[0].brand,
      image: product.image,
      quantity: quantity,
      item: product,
    };

    //selectedItem(value);
       console.log('item=>',userId, value);
       dispatch(addCart({userId, value}));
       closeCartDialog();
    //setCart((prev) => [...prev,value]);
  };

  const handleBackBtn = () => {

  }
  return (
    <div>
        <Navbar />
      {/* <h1 className="text-red-500 text-2xl">
        Product Data - {category} {brand} {id}
      </h1> */}
      {product && (
        <div className="p-10 lg:ml-40 md:ml-20 sm:ml-0 relative">
          <div className="absolute top-7 left-0">
            <Link to={-1} className="border-1 rounded-lg px-2 cursor-pointer" >Back</Link>
          </div>
          <div className="flex flex-row w-80% gap-10">
            <div className="">
            <img
            src={product.image}
            alt={product.name}
            className="w-60 h-60 object-cover my-4"
          />
            </div>
            <div className="flex flex-col items-start gap-5 px-5">
            <h1 className="font-bold text-2xl">{product.name}</h1>
            <div className="flex items-center">
            <p className=" text-gray-600">Price: <span className="text-xl font-semibold text-black">₹{product.price}</span></p>
            <p className="text-sm text-red-500">(5% off)</p>
            </div>
          <p className="text-gray-500">Category: {category}</p>
          <p className="text-gray-500">Brand: {brand}</p>
          <div className="w-[100%]">
          <button
            className="bg-blue-400 px-5 py-2 cursor-pointer rounded-md"
            onClick={showCartDialog}
          >
            Add to Cart
          </button>

          </div>
            </div>
          </div>
          
          
        </div>
      )}
    <p className="text-start text-xl font-semibold mb-5">Similar Products:-</p>
      {categoryData.map((category, index) => (
        <div key={index} className="mb-6">
          <h3 className="text-xl font-semibold mb-2">
            {category.category || "Unknown category"}
          </h3>
          <h3 className="text-xl font-semibold mb-2">
            {category.brand || "Unknown Brand"}
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {Array.isArray(category.items) ? (
              category.items.map((item) => (
                <div
                  key={item.id}
                  className="border p-3 rounded-lg shadow-md cursor-pointer"
                >
                  <h4 className="text-lg font-semibold">{item.name}</h4>
                  <p>₹{item.price}</p>
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-32 object-contain mt-2"
                  />
                </div>
              ))
            ) : (
              <p>No items found for this category.</p>
            )}
            {}
          </div>
        </div>
      ))}
      <Dialog
        open={dialogOpen}
        onClose={closeCartDialog}
        sx={{
          "& .MuiDialog-paper": {
            width: "500px",
          },
        }}
      >
        <DialogTitle>Add To Cart</DialogTitle>
        <DialogContent>
          {selectedItem && (
            <div className="w-full flex flex-row ">
              <img src={selectedItem.image} className="w-20 h-20" />
              <div className="w-full p-2">
              <p>{selectedItem.name}</p>
              <div className="flex flex-row gap-2">
              <p>₹ {selectedItem.price}</p>
              <p>Quantity:</p>
              <select value={quantity} onChange={(e)=>setQuantity(e.target.value)} className="border-1 rounded-md ">
                {values.map((num)=>(
                    <option key={num} value={num}>
                        {num}
                    </option>
                ))}
              </select>

              </div>
              </div>
            </div>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={closeCartDialog} variant="outlined" color="error">
            Cancel
          </Button>
          <Button onClick={addToCart} variant="contained" color="primary">
            Add
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default SingleProduct;
