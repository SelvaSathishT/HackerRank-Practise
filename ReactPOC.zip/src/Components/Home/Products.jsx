import React, { useContext } from 'react';
import Ad1 from "../../Assets/Ad1.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { DataContext } from '../../Datacontext';
import { useNavigate } from 'react-router-dom';


const ProductsData = [
    {
        id: 1,
        img: Ad1,
        title: 'BAT',
        rating: 5.0,
        color: 'White',
        aosDelay: '0',
        category: 'Bats'
    },
    {
        id: 2,
        img: '/images/stumps.png',
        title: 'Stump',
        rating: 4.0,
        color: 'White',
        aosDelay: '100',
        category: 'Stumps'
    },
    {
        id: 3,
        img: '/images/ball.png',
        title: 'Ball',
        rating: 4.5,
        color: 'Red',
        aosDelay: '100',
        category: 'Balls'
    },
    {
        id: 4,
        img: '/images/protective-gear.png',
        title: 'Protective Gear',
        rating: 4.0,
        color: 'Black',
        aosDelay: '100',
        category: 'Protective Gear'
    },
    {
        id: 5,
        img: '/images/kit.png',
        title: 'Kit',
        rating: 4.0,
        color: 'White',
        aosDelay: '100',
        category: 'Kits'
    },
];

const Products = () => {
    let navigate = useNavigate();
    const { setSelectedCategory } = useContext(DataContext);

    const handleProductClick = (data) => {
        console.log('item=>',data.category);
        setSelectedCategory(data.category);
        navigate('/products');
    }
  return (
    <div className='mt-14 mb-12'>
      <div className='container'>
        {/* header */}
        <div className='text-center mb-10 max-w-[full]'>
            <p data-aos="fade-up" className='text-sm text-blue-400'>Top Selling Products for you</p>
            <h1 data-aos="fade-up" className='text-3xl font-bold'>Products</h1>
            <p data-aos="fade-up" className='text-xs text-gray-400'>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore odit quisquam quia amet sint. Ratione?
            </p>
        </div>
        {/* body */}
        <div>
            <div className='grid grid-cols-1 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 place-items-center gap-5'>
                {ProductsData.map((data) => (
                    <div data-aos="fade-up" data-aos-delay={data.aosDelay} key={data.id} className='space-y-3 cursor-pointer' onClick={()=>handleProductClick(data)}>
                        <img src={data.img} alt="" className='h-[220px] w-[150px] object-contain rounded-md'/>
                        <div>
                            <h3 className='font-semibold'>{data.title}</h3>
                            <p className='text-sm text-gray-600'>{data.color}</p>
                            <div className='flex items-center gap-1'>
                            <FontAwesomeIcon icon={faStar} className='text-yellow-400' />
                            <span>{data.rating}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
      </div>
    </div>
  )
}

export default Products
