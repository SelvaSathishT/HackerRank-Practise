import React, { useContext } from 'react';
import Logo from '../../Assets/tss-logo.png';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from 'react-router-dom';
import { DataContext } from '../../Datacontext';

const Brands = [
    {
        id: 1,
        img: Logo,
        title: 'Gray-Nicolls',
        des: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate fuga neque quisquam corrupti natus eveniet?',
        brand: 'Gray-Nicolls'
    },
    {
        id: 2,
        img: Logo,
        title: 'SS',
        brand: 'SS',
        des: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate fuga neque quisquam corrupti natus eveniet?'
    },
    {
        id: 3,
        img: Logo,
        title: 'Team SG',
        brand: 'SG',
        des: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate fuga neque quisquam corrupti natus eveniet?'
    }
];

const TopBrands = () => {
    let navigate = useNavigate();
    const { setSelectedBrand } = useContext(DataContext);

    const handleBrandClick = (data) => {
        console.log('brand =>',data.brand);
        setSelectedBrand(data.brand);
        navigate('/products');
    }
  return (
    <div>
     <div className='container'>
    {/* head */}
    <div className='text-center mb-24'>
            <p data-aos="fade-up" className='text-sm text-blue-400'>Top Brands for you</p>
            <h1 data-aos="fade-up" className='text-3xl font-bold'>Brands</h1>
            <p data-aos="fade-up" className='text-xs text-gray-400'>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore odit quisquam quia amet sint. Ratione?
            </p>
        </div>
        {/* body */}
        <div className='grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-20 md:gap-5 place-items-center'>
            {Brands.map((data) => (
                <div data-aos='zoom-in' onClick={()=>handleBrandClick(data)} className='rounded-2xl bg-white hover:bg-black/80 hover:text-white relative shadow-xl duration-300 group max-w-[300px]'>
                    <div className='h-[50px]'>
                        <img src={data.img} alt='' className='max-w-[140px] block mx-auto transform -translate-y-20 group-hover:scale-105 duration-300 drop-shadow-md'/>
                    </div>
                    <div className='p-4 text-center'>
                        <div className='w-full flex items-center justify-center gap-1'>
                            <FontAwesomeIcon icon={faStar} className='text-yellow-400' />
                            <FontAwesomeIcon icon={faStar} className='text-yellow-400' />
                            <FontAwesomeIcon icon={faStar} className='text-yellow-400' />
                            <FontAwesomeIcon icon={faStar} className='text-yellow-400' />
                        </div>
                        <h1 className='text-xl font-bold'>{data.title}</h1>
                        <p className='text-gray-500 group-hover:text-white duration-300 text-sm line-clamp-2'>{data.des}</p>
                        <button className='bg-blue-400 hover:scale-105 duration-300 text-white py-1 px-4 rounded-full mt-4 group-hover:bg-white group-hover:text-blue-400'>
                            Order Now
                        </button>
                    </div>
                </div>
            ))}
        </div>

     </div>
    </div>
  )
}

export default TopBrands
