import React, { useContext } from "react";
import Ad1 from "../../Assets/Ad1.png";
import Ad2 from "../../Assets/Ad2.png";
import Ad3 from "../../Assets/Ad3.png";
import Slider from "react-slick";
import { useNavigate } from "react-router-dom";
import { DataContext } from "../../Datacontext";

const AdImgs = [
  {
    id: 1,
    img: Ad1,
    category: 'Bats',
    title: `LIGHTWEIGHT... MORE SIX HITS...`,
    des: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.`,
  },
  {
    id: 2,
    img: Ad2,
    category: 'Protective Gear',
    title: `WEAR YOUR SHIELD.. MOVE FORWARD THE GAME...`,
    des: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.`,
  },
  {
    id: 3,
    img: Ad3,
    category: 'Kits',
    title: `UPTO 50% off on all Combo`,
    des: `Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.`,
  },
];

const Ads = () => {
  const navigate = useNavigate();
  const {setSelectedCategory} = useContext(DataContext);
  
  var settings = {
    dots: false,
    arrows: false,
    infinite: true,
    speed: 800,
    slidesToScoll: 1,
    autoplay: true,
    autoplaySpeed: 4000,
    cssEase: "ease-in-out",
    pauseOnHover: false,
    pauseOnFocus: true,
  };

  const handleAdClick = (data) => {
    console.log('data =>',data.category);
    setSelectedCategory(data.category);
    navigate('/products');
  }
  return (
    <div className="relative overflow-hidden min-h-[350px] sm:min-h-[450px] bg-gray-100 flex justify-center items-center duration-200">
      <div className="h-[300px] w-[300px] bg-blue-400/20 absolute -top-1/2 right-0 rounded-3xl rotate-45 -z-9"></div>
      <div className="container pb-8 sm:pb-0">
        <Slider {...settings}>
          {AdImgs.map((data) => (
            <div>
              <div className="grid grid-cols-1 sm:grid-cols-2">
                <div className="flex flex-col justify-center gap-4 pt-12 sm:pt-0 text-center sm:text-left order-2 sm:order-1 relative z-10">
                  <h1 data-aos='zoom-out' data-aos-duration='500' data-aos-once='true' className="text-5xl sm:text-6xl lg:text-7xl">
                    {data.title}
                  </h1>
                  <p data-aos='fade-up' data-aos-duration='500' data-aos-delay='100' className="text-sm">{data.des}</p>
                  <div data-aos='fade-up' data-aos-duration='500' data-aos-delay='300'>
                    <button onClick={()=>handleAdClick(data)} className="bg-gradient-to-r from-blue-400 to-blue-900 hover:scale-105 duration-200 text-white py-2 px-4 rounded-full">
                      Explore
                    </button>
                  </div>
                </div>
                {/* image */}
                <div className="order-1 sm:order-2">
                  <div data-aos='zoom-in' data-aos-once='true' className="relative z-10">
                    <img
                      src={data.img}
                      alt=""
                      className="w-[300px] h-[300px] sm:h-[450px] sm:w-[450px] sm:scale-105 lg:scale-120 object-contain mx-auto"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    </div>
  );
};

export default Ads;
