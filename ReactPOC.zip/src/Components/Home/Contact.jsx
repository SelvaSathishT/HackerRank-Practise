import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import { contactUs } from '../../Data/textData'

const Contact = () => {
  return (
    <div>
      <Navbar />
      <div className="w-full p-10">
        <h1 className="font-bold m-5 text-3xl text-start">Contact</h1>
        <p>{contactUs}</p>
      </div>
      <Footer />
    </div>
  )
}

export default Contact
