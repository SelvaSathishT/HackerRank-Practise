import React from 'react';
import { useNavigate } from "react-router";
import Logo from '../../Assets/tss-logo.png';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass, faUser, faCartShopping, faCaretDown } from "@fortawesome/free-solid-svg-icons";
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '../../Slices/AuthSlice';

const Menu = [
  {
    id: 1,
    name: 'Home',
    dropdown: '',
    navigate: '/'
  },
  {
    id: 2,
    name: 'About',
    navigate: '/about'
  },
  {
    id: 3,
    name: 'Categories',
    navigate: '/categories'
  },
  {
    id: 4,
    name: 'Brands',
    navigate: '/brands'
  },
  {
    id: 5,
    name: 'Contact Us',
    navigate: '/contact'
  },
];

const DropdownLinks = [
  {
    id:1,
    name:'Trending Products',
    link:'/#'
  },
  {
    id:2,
    name:'Best Selling',
    link:'/#'
  },
  {
    id:3,
    name:'Trending Rated',
    link:'/#'
  }
]

const Navbar = () => {
  let navigate = useNavigate();
  const dispatch = useDispatch();
  const userName = useSelector(state => state.auth.name);
  const userId = useSelector(state => state.auth.data.id || 6);

  const handleLogout = () => {
    dispatch(logout());
    navigate('/login')
  };

  const handleNavClick = (data) => {
    console.log('data =>',data.navigate);
    navigate(data.navigate);
  }

  return (
    <div className='shadow-md sticky top-0 bg-white duration-200 relative z-40'>
      {/* upper Nav */}
      <div className='bg-blue-400/40 py-2 w-full sm:py-0'>
        <div className=' w-full flex justify-between items-center '>
          <div onClick={()=> navigate('/')}>
            <a href='' className='font-bold text-2xl sm:text-3xl flex gap-2'>
              <img src={Logo} alt='Logo' className='w-10 rounded-md lg:ml-12 md:ml-12 sm:ml-0'/>
              
            </a>
          </div>
          <div>
            <span className='font-bold text-2xl sm:text-xl'>TSS - Sports</span>
          </div>
          {/* search-bar */}
          <div className='flex justify-between items-center gap-4'> 
            
          {/* cart button */}
          {userName && <button onClick={e => {e.preventDefault() ;navigate(`/mycart?id=${userId}`);}} className='bg-gradient-to-r from-blue-400 to-blue-900 transition-all duration-200 text-white py-1 px-4 rounded-full flex items-center gap-3 group'>
            <span className='group-hover:block transition-all duration-200 hidden md:inline lg:inline'>Cart</span>
            <FontAwesomeIcon icon={faCartShopping} className='text-xl text-white drop-shadow-sm cursor-pointer' />
          </button>}
          {/* user button */}
          <div className='group relative cursor-pointer '>
          <button 
          className='bg-gradient-to-r from-blue-400 to-blue-900 transition-all duration-200 text-white py-1 px-4 group-hover:text-red rounded-full flex items-center gap-3 '>
            <span className='transition-all duration-200 hidden md:inline lg:inline'>{userName ? userName : 'User'}</span>
            <FontAwesomeIcon icon={faUser} className='text-xl text-white drop-shadow-sm ' />
          
          <div className='absolute z-[999] hidden group-hover:block w-[100px] rounded-md bg-white p-1 text-black shodow-md top-8 left-[2px] cursor-pointer'
          onClick={handleLogout} 
          >
                <ul>
                  <li className='inline-block w-full rounded-md p-1 hover:bg-blue-400/20 '>{userName ? 'Logout': 'Login'}</li>
                </ul>
              </div>
              </button>
          </div>
          </div>
        </div>
      </div>
      {/* lower Nav */}
      <div className='flex justify-center'>
        <ul className='grid grid-cols-3 sm:grid-cols-5 items-center w-full py-2 justify-center' 
        //onClick={()=> navigate('/products')}
        >
          {Menu.map((data) => (
            <li key={data.id} onClick={() => handleNavClick(data)} className='cursor-pointer'>
              <p className='inline-block px-4 sm:px-0 hover:text-blue-400 duration-200' >{data.name}</p>
            </li>
          ))}
          {/* <li className='group relative cursor-pointer'>
            <a href='#' className='flex items-center gap-[2px] py-2'>
              Trending
              <span>
              <FontAwesomeIcon icon={faCaretDown} className='transition-all duration-200 group-hover:rotate-180'/>
              </span>
              <div className='absolute z-[999] hidden group-hover:block w-[200px] rounded-md bg-white p-2 text-black shodow-md top-10'>
                <ul>
                  {DropdownLinks.map((data)=>(
                    <li key={data.id}>
                      <a href={data.link} className='inline-block w-full rounded-md p-2 hover:bg-blue-400/20 '>{data.name}</a>
                    </li>
                  ))}
                </ul>
              </div>
            </a>

          </li> */}
        </ul>
        
      </div>
    </div>
  )
}

export default Navbar;

// <div className='sticky top-0 bg-white z-10'>
//       <div className='container hidden lg:block'>
//         <div className='flex justify-between items-center p-8'>
//             <h1 className='text-4xl font-medium'>TSS - Logo</h1>
//             <div className='relative w-full max-w-[500px]'>
//                 <input type='text' className='bg-[#f2f3f5] border-none outline-none px-6 py-3 rounded-[30px] w-full' placeholder='Search Product...'/>
//                 <FontAwesomeIcon icon={faMagnifyingGlass} size={20} className='absolute top-0 right-0 mt-4 mr-5 text-gray-500'/>
//             </div>

//             <div className='flex gap-4'>
//                 <div className='border border-gray-400 rounded-full w-[50px] h-[50px] grid place-items-center text-[22px]'>
//                 <FontAwesomeIcon icon={faUser} />
//                 </div>
//                 <div className='border border-gray-400 rounded-full w-[50px] h-[50px] grid place-items-center text-[22px] relative'>
//                 <FontAwesomeIcon icon={faCartShopping} />
//                 </div>
//             </div>
//         </div>

//       </div>
//     </div>
