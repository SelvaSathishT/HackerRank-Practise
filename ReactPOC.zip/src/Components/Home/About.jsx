import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import { aboutUs } from "../../Data/textData.js";

const About = () => {
  return (
    <div>
      <Navbar />
      <div className="w-full p-10">
        <h1 className="font-bold m-5 text-3xl text-start">About</h1>
        <p>{aboutUs}</p>
      </div>
      <Footer />
    </div>
  );
};

export default About;
