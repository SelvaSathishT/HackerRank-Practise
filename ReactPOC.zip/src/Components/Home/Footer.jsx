import React from 'react';
import Ad1 from '../../Assets/Ad1.png';
import Logo from '../../Assets/tss-logo.png';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFacebook, faLinkedin, faInstagram } from '@fortawesome/free-brands-svg-icons';
import { faLocationDot, faMobileScreen } from "@fortawesome/free-solid-svg-icons";
 
const BannerImg = {
    // backgroundImage: `url(${Ad1})`,
    // backgroundPosition: 'bottom',
    // backgroundRepeat: 'no-repeat',
    // backgroundSize: 'cover',
    backgroundColor: '#45433e',
    height: '100%',
    width: '100%'
};

const FooterLinks = [
    {
        id: 1,
        title:'Home',
        link: '/#'
    },
    {
        id: 2,
        title:'About',
        link: '/#'
    },
    {
        id: 3,
        title:'Contact',
        link: '/#'
    },
    
]

const Footer = () => {
  return (
    <div style={BannerImg} className='text-white '>
      <div className='container'>
        <div 
        //data-aos='zoom-in' 
        className='grid md:grid-cols-3 pb-10 pt-5'>
            {/* details */}
            <div className='py-8 px-4 flex flex-col items-center justify-center'>
                    <img src={Logo} alt='' className='max-w-[50px] rounded-lg'/>
                <h1 className='sm:text-3xl text-xl font-bold sm:text-left text-justify mb-3 flex items-center gap-3'>
                    TSS - Sports
                </h1>
                {/* <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt assumenda soluta, libero laborum nostrum culpa consectetur labore fuga. Debitis, fuga! Facilis tenetur ullam provident sit reiciendis dolorem velit voluptatibus nostrum!</p> */}
            </div>
            {/* links */}
            <div className='grid grid-cols-2 sm:grid-cols-3 col-span-2 md:pl-10'>
                <div className='flex items-center gap-5em justify-center'>
                    <div className='py-8 px-4'>
                        <h1 className='sm:text-3xl text-xl font-bold sm:text-left text-justify mb-3'>Important Links</h1>
                        <ul>
                            {FooterLinks.map((link)=>(
                                <li className='cursor-pointer hover:text-blue-400 hover:translate-x-1 duration-300 text-gray-200' key={link.title}>
                                    <span>{link.title}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
                    <div className='flex flex-col items-center gap-3 mt-6'>
                        <h1 className='sm:text-3xl text-xl font-bold sm:text-left text-justify mb-3'>Social Links</h1>
                            <a href=""><FontAwesomeIcon icon={faFacebook} className='text-2xl'/> tss-sports</a>
                            <a href=""><FontAwesomeIcon icon={faInstagram} className='text-2xl'/> tss-sports</a>
                            <a href=""><FontAwesomeIcon icon={faLinkedin} className='text-2xl'/> tss-sports</a>
                            
                    </div>
                {/* social */}
                <div className='flex flex-col items-center gap-5em justify-center'>
                    <div clasName='mt-6'>
                        <h1 className='sm:text-3xl text-xl font-bold sm:text-left text-justify mb-3'>Reach Us</h1>
                        <div className='flex items-center gap-3'>
                        <FontAwesomeIcon icon={faLocationDot} />
                        <p>xxx - yyy</p>
                        </div>
                        <div className='flex items-center gap-3'>
                        <FontAwesomeIcon icon={faMobileScreen} />
                        <p>00 0000 0000</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <div className='mx-5 border-t-2 p-5'>
        <p>© 2025 @TSS - Sports. All rights reserved</p>
      </div>
    </div>
  )
}

export default Footer
