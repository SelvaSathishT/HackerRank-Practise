import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import LoginBG from "../Assets/LoginBG.png";
import Logo from "../Assets/tss-logo.png";
import { users } from "./../Data/users";
import { useDispatch, useSelector } from "react-redux";
import { login } from "../Slices/AuthSlice";
import Snackbar from "@mui/material/Snackbar";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormHelperText,
  Button,
} from "@mui/material";
import { register } from "../Slices/UsersSlice";

const Login = () => {
  let navigate = useNavigate();
  const dispatch = useDispatch();
  var initialData = {
    email: "",
    password: "",
  };
  const registerData = {
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  };
  const [formValue, setFormValue] = useState(initialData);
  const [errors, setErrors] = useState({});
  const [snackOpen, setSnackOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [regFormValue, setRegFormValue] = useState(registerData);
  const [regErrors, setRegErrors] = useState({});
  const [snackMsg, setSnackMsg] = useState("");
  const [successSnack, setSuccessSnack] = useState(true);
  //const [newUsers, setNewUsers] = useState([]);

  var newUsers = useSelector((state) => state.users.users);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValue((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleRegInputChange = (e) => {
    const { name, value } = e.target;
    setRegFormValue((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateForm = () => {
    let errors = {};
    if (!formValue.email) {
      errors.email = `Email is required.`;
    } else if (!/\S+@\S+\.\S/.test(formValue.email)) {
      errors.email = `Invalid email format.`;
    }
    if (!formValue.password) {
      errors.password = `Password is requiered.`;
    } else if (formValue.password.length < 6) {
      errors.password = "Password must be atleast 6 characters.";
    }

    return errors;
  };

  const validateForm1 = () => {
    let errors = {};
    if (!formValue.email) {
      errors.email = `Email is required.`;
    } else if (!/\S+@\S+\.\S/.test(formValue.email)) {
      errors.email = `Invalid email format.`;
    }
    if (!formValue.password) {
      errors.password = `Password is requiered.`;
    } else if (formValue.password.length < 6) {
      errors.password = "Password must be atleast 6 characters.";
    }

    return errors;
  };

  const validateRegForm = () => {
    let errors = {};
    if (!regFormValue.name) {
      errors.name = `Email is required.`;
    }
    if (!regFormValue.email) {
      errors.email = `Email is required.`;
    } else if (!/\S+@\S+\.\S/.test(regFormValue.email)) {
      errors.email = `Invalid email format.`;
    }
    if (!regFormValue.password) {
      errors.password = `Password is requiered.`;
    } else if (regFormValue.password.length < 6) {
      errors.password = "Password must be atleast 6 characters.";
    }
    if (regFormValue.confirmPassword !== regFormValue.password) {
      errors.consfirmPassword = "Passwords do not match.";
    }
    setRegErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleRegister = (e) => {
    e.preventDefault();
    if (validateRegForm()) {
      dispatch(
        register({
          name: regFormValue.name,
          email: regFormValue.email,
          password: regFormValue.password,
        })
      );
      setSnackOpen(true);
      setSnackMsg("Registrated sucessfully...");
      setSuccessSnack(true);
      handleRegClose();
    }
  };

  const handleRegClose = () => {
    setRegisterOpen(false);
    setRegFormValue(registerData);
    setRegErrors({});
  };

  const handleLogin = (e) => {
    e.preventDefault();
    const validation = validateForm();
    setErrors(validation);

    if (Object.keys(validation).length === 0) {
      const userExist =
        newUsers.find(
          (user) =>
            user.email === formValue.email &&
            user.password === formValue.password
        ) ||
        users.find(
          (user) =>
            user.email === formValue.email &&
            user.password === formValue.password
        );
      console.log("user=>", userExist);
      if (userExist) {
        dispatch(
          login({
            name: userExist.name,
            email: userExist.email,
            data: userExist
          })
        );
        navigate("/");
      } else {
        setSnackMsg("Login failed....");
        setSuccessSnack(false);
        setSnackOpen(true);
      }
    }
  };
  return (
    <div className="w-full h-screen flex items-start bg-white">
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "right" }}
        open={snackOpen}
        message={snackMsg}
        autoHideDuration={1000}
        sx={{
          "& .MuiSnackbarContent-root": {
            backgroundColor: successSnack ? "green" : "red",
            color: "black",
          },
        }}
      />
      <div className="relative w-1/2 h-full flex flex-col">
        <div className="absolute top-[0%] left-[10%] flex flex-col">
          <h1 className="text-4xl text-blue-900 font-bold my-4">
            One Step Cricket Store.
          </h1>
          <p className="text-xl text-blue-700 font-normal">
            Start for Free and get excited items.
          </p>
        </div>
        <img
          src={LoginBG}
          className="w-full h-full pt-25 object-cover border border-1"
        />
      </div>

      <div className="w-1/2 h-full bg-white flex flex-col p-10 items-center justify-between">
        <div className="w-full flex items-center justify-center max-w-[400px]">
          <img src={Logo} alt="" className="h-15 w-15 border-2 rounded-full" />
          <h1 className="text-xl text-black font-semibold">TSS - Sports</h1>
        </div>

        <div className="w-full flex flex-col max-w-[400px]">
          <div className="w-full flex flex-col items-start mb-2">
            <h3 className="text-3xl font-semibold mb-2">Login</h3>
            <p className="text-base mb-2">
              Welcome Back! Please enter your details.
            </p>
          </div>

          <div className="w-full flex flex-col">
            <form onSubmit={handleLogin}>
              <input
                type="email"
                name="email"
                value={formValue.email}
                onChange={handleInputChange}
                placeholder="Email"
                className="w-full text-black py-2 bg-transparent px-2 my-2 border-b border-black outline-none focus:outline-none"
              />
              {errors.email && (
                <p className="text-red-500 text-start text-sm">
                  {errors.email}
                </p>
              )}
              <input
                type="password"
                name="password"
                value={formValue.password}
                onChange={handleInputChange}
                placeholder="Password"
                className="w-full text-black px-2 py-2 bg-transparent my-2 border-b border-black outline-none focus:outline-none"
              />
              {errors.password && (
                <p className="text-red-500 text-sm text-start">
                  {errors.password}
                </p>
              )}
              <button
                type="submit"
                className="w-full text-white bg-black hover:bg-white hover:text-black border   cursor-pointer my-2 font-semibold rounded-md p-4 text-center flex items-center justify-center"
              >
                Log in
              </button>
            </form>
          </div>

          <div className="w-full flex flex-col">
            {/* <button className='w-full text-black bg-white my-2 font-semibold border-2 border-black rounded-md p-4 text-center flex items-center justify-center'>
                            Register
                        </button> */}
          </div>
        </div>

        <div className="w-full flex items-center justify-center my-4">
          <p className="text-sm font-normal text-black">
            Don't have a account?{" "}
            <span
              className="font-semibold hover:font-bold underline underline-offset-2 cursor-pointer text-black"
              onClick={() => setRegisterOpen(true)}
            >
              Sign Up
            </span>
          </p>
        </div>
      </div>

      <Dialog open={registerOpen} onClose={handleRegClose} sx={{
        '& .MuiDialog-paper': {
            width: '500px'
        }
      }}>
        <DialogTitle>New User Registration</DialogTitle>
        <DialogContent>
          <form onSubmit={handleRegister}>
            <TextField
              fullWidth
              label="Name"
              name="name"
              value={regFormValue.name}
              onChange={handleRegInputChange}
              error={!!errors.name}
              margin="dense"
            />
            <FormHelperText error>{regErrors.name}</FormHelperText>
            <TextField
              fullWidth
              label="Email"
              type="email"
              name="email"
              value={regFormValue.email}
              onChange={handleRegInputChange}
              error={!!errors.email}
              margin="dense"
            />
            <FormHelperText error>{regErrors.email}</FormHelperText>
            <TextField
              fullWidth
              label="Password"
              type="password"
              name="password"
              value={regFormValue.password}
              onChange={handleRegInputChange}
              error={!!errors.password}
              margin="dense"
            />
            <FormHelperText error>{regErrors.password}</FormHelperText>
            <TextField
              fullWidth
              label="Confirm Password"
              type="password"
              name="confirmPassword"
              value={regFormValue.confirmPassword}
              onChange={handleRegInputChange}
              error={!!errors.confirmPassword}
              margin="dense"
            />
            <FormHelperText error>{regErrors.confirmPassword}</FormHelperText>
          </form>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleRegClose} variant="outlined" color="error">
            Cancel
          </Button>
          <Button onClick={handleRegister} variant="contained" color="primary">
            Register
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default Login;
