import React, { useContext, useEffect } from 'react'
import Navbar from './Home/Navbar'
import Footer from './Home/Footer'
import { useNavigate } from 'react-router-dom'
import { DataContext } from '../Datacontext'

const Brands = ({allProducts}) => {
  let navigate = useNavigate();
  const {setSelectedBrand, setSelectedCategory} = useContext(DataContext);

    useEffect(() => {
            window.scrollTo(0, 0);
          }, []);
    
    const brands = [...new Set(allProducts.map((p)=> p.brand))];

    const handleBrandClick = (brand) => {
      console.log('brand=>',brand);
      setSelectedCategory('');
      setSelectedBrand(brand);
      navigate('/products');
    }
  return (
    <div>
      <Navbar />
      <div className='w-full p-10'>
        <h1 className='text-2xl text-start font-bold'>All Brands</h1>
        <div className='grid  md:grid-cols-4 sm:grid-cols-2 gap-3 p-3'>
            {brands.map((brand,index)=>(
                  <div onClick={() => handleBrandClick(brand)} className='border-1 shadow-lg border-gray-300 font-l m-8 flex items-center justify-center h-20 rounded-lg cursor-pointer'>
                  {brand}
                  </div>
            ))}
            </div>
      </div>
      <Footer />
    </div>
  )
}

export default Brands
