import React, { useContext, useEffect, useState } from 'react';
import { useNavigate } from "react-router";
import { useDispatch, useSelector } from 'react-redux';
import { login, logout } from '../Slices/AuthSlice';
import Navbar from './Home/Navbar';
import Ads from './Home/Ads';
import Products from './Home/Products';
import AOS from 'aos';
import 'aos/dist/aos.css'
import TopBrands from './Home/TopBrands';
import Banner from './Home/Banner';
import Testimonials from './Home/Testimonials';
import Footer from './Home/Footer';
import { DataContext } from '../Datacontext';

const Main = () => {
  const dispatch = useDispatch();
  const {setSelectedCategory, setSelectedBrand} = useContext(DataContext);
    const [alp,setAlp] = useState();
    const userName = useSelector(state => state.auth.name );
    const {state} = useContext(DataContext);

    useEffect(()=>{
      AOS.init({
        offset: 100,
        duration: 800,
        easing: 'ease-in-sine',
        delay: 100,
      });
      AOS.refresh();
      console.log("Data context => ",state);
      setSelectedBrand("");
      setSelectedCategory("");
    },[])

    //console.log('hii',userName);
    
    const handleLogin = () => {
      dispatch(login({
        name:'selva'
      }))
    };

    const handleLogout = () => {
      dispatch(logout());
    }
  return (
    <div className='bg-white duration-200'>
      {/* <div className='p-4 bg-red-400'>tss</div>
      <button className='btn btn-primary' onClick={handleLogin}>login</button>
      <button className='border rounded-lg shadow-2xl' onClick={handleLogout}>logout</button> */}
        <Navbar />
        <Ads />
        <Products />
        <TopBrands />
        <Banner />
        <Testimonials />
        <Footer />

    </div>
  )
};

export default Main;
