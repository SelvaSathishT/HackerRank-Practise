import React from 'react';
import Data from '../Data/cricketing_goods_modified.json';
import Bats from '../Data/cricket_bats.json';
import Balls from '../Data/cricket_balls.json';
import Protection from '../Data/protective_gear.json';
import Shoes from '../Data/cricket_shoes.json';
import Clothing from '../Data/cricket_clothing.json';
import Stumps from '../Data/cricket_stumps.json';
import WicketKeeping from '../Data/wicket_keeping_equipment.json';
import Kit from '../Data/cricket_kit.json';
import Bags from '../Data/cricket_bags.json';
import Accessories from '../Data/cricket_accessories.json';

const allProducts = [
  ...Bats,
  ...Balls,
  ...Protection,
  ...Shoes,
  ...Clothing,
  ...Stumps,
  ...WicketKeeping,
  ...Kit,
  ...Bags,
  ...Accessories,
];

const JsonData = () => {
  return (
    <div className="p-5">
      <h2 className="text-2xl font-bold mb-4">Cricket Collection</h2>
      {allProducts.map((category, index) => (
        <div key={index} className="mb-6">
          <h3 className="text-xl font-semibold mb-2">{category.category || 'Unknown category'}</h3>
          <h3 className="text-xl font-semibold mb-2">{category.brand || 'Unknown Brand'}</h3>
          <div className="grid grid-cols-3 gap-4">
            {Array.isArray(category.items) ? (
              category.items.map((item) => (
                <div key={item.id} className="border p-3 rounded-lg shadow-md">
                  <h4 className="text-lg font-semibold">{item.name}</h4>
                  <p>₹{item.price}</p>
                  <img src={item.image} alt={item.name} className="w-full h-32 object-contain mt-2" />
                </div>
              ))
            ) : (
              <p>No items found for this category.</p>
            )}
            {}
          </div>
        </div>
      ))}
    </div>
  );
}

export default JsonData
