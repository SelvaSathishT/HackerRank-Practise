export const users = [
    {
        id: 1,
        name: "Selva",
        email: "selva@gmail.com",
        password: "pass@123"
    },
    {
        id: 2,
        name: "John",
        email: "john@gmail.com",
        password: "pass@123"
    },
    {
        id: 3,
        name: "Smith",
        email: "smith@gmail.com",
        password: "pass@123"
    },
    {
        id: 4,
        name: "Alice",
        email: "alice@gmail.com",
        password: "pass@123"
    },
    {
        id: 5,
        name: "Bob",
        email: "bob@gmail.com",
        password: "pass@123"
    },
]