const aboutUs = `Welcome to TSS - Sports, your ultimate destination for all things cricket! Whether you're a seasoned player or just starting out, we are here to provide you with the best cricket gear and accessories to elevate your game.

At TSS - Sports, we pride ourselves on offering a wide range of high-quality products, including bats, balls, protective gear, clothing, and more. Our selection features top brands and the latest innovations in cricket equipment, ensuring you have everything you need to perform at your best.

Our mission is to support cricket enthusiasts of all levels by providing exceptional customer service, expert advice, and a seamless shopping experience. We understand the passion and dedication that cricket demands, and we are committed to helping you achieve your goals on the field.

Thank you for choosing TSS - Sports as your trusted cricket goods provider. Let's play the game we love with the best gear available!`;


const contactUs = `Reach out to TSS - Sports for all your cricket gear needs! Visit us at our Mylapore store or contact us via phone or email. Our dedicated customer service team is available Monday to Saturday to assist you. Follow us on social media for the latest updates and offers.`

const contactData = `Address:
123 Cricket Lane,
Mylapore, Chennai,
Tamil Nadu, 600004, India

Phone:
+91 98765 43210

Email:
support@tss-sports.com`
export {
    aboutUs,
    contactUs
}