import { configureStore } from '@reduxjs/toolkit';
import { counterSlice } from './Slices/CounterSlice';
import { authReducer } from './Slices/AuthSlice';
import { persistStore } from 'redux-persist';
import { usersReducer } from './Slices/UsersSlice';
import { cartReducer } from './Slices/CartSlice';


const store = configureStore({
    reducer: {
      counter: counterSlice,
      auth: authReducer,
      users: usersReducer,
      carts: cartReducer
    },
  });
  
  export const persistor = persistStore(store);

  export default store;
