import React from "react";
import { Route, Routes } from "react-router-dom";
import Main from "../Components/Main";
import Login from "../Components/Login";
import JsonData from '../Components/JsonData';
import AllProducts from "../Components/Products/AllProducts";
import Bats from '../Data/cricket_bats.json';
import Balls from '../Data/cricket_balls.json';
import Protection from '../Data/protective_gear.json';
import Shoes from '../Data/cricket_shoes.json';
import Clothing from '../Data/cricket_clothing.json';
import Stumps from '../Data/cricket_stumps.json';
import WicketKeeping from '../Data/wicket_keeping_equipment.json';
import Kit from '../Data/cricket_kit.json';
import Bags from '../Data/cricket_bags.json';
import Accessories from '../Data/cricket_accessories.json';
import SingleProduct from "../Components/Products/SingleProduct";
import Cart from "../Components/Cart";
import About from "../Components/Home/About";
import Contact from "../Components/Home/Contact";
import Categories from "../Components/Categories";
import Brands from "../Components/Brands";

const allProducts = [
  ...Bats,
  ...Balls,
  ...Protection,
  ...Shoes,
  ...Clothing,
  ...Stumps,
  ...WicketKeeping,
  ...Kit,
  ...Bags,
  ...Accessories,
];


const RoutesPage = () => {
    return (
        <Routes>
            {/* <Route path="/" element={<Form />} /> */}
            <Route path="/" element={<Main />} />
            <Route path="/login" element={<Login />} />
            <Route path="/json" element={<JsonData />}/>
            <Route path="/products" element={<AllProducts allProducts={allProducts}/>}/>
            <Route path="/item" element={<SingleProduct allProducts={allProducts}/>}/>
            <Route path="/mycart" element={<Cart />}/>
            <Route path="/about" element={<About />}/>
            <Route path="/contact" element={<Contact />}/>
            <Route path="/categories" element={<Categories allProducts={allProducts}/>}/>
            <Route path="/brands" element={<Brands allProducts={allProducts}/>}/>
        </Routes>
    );
};

export default RoutesPage;