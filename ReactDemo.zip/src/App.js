import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import RoutesPage from './Routes/Routes';

const App = () => {
    return (
        <Router>
            <RoutesPage />
        </Router>
    );
};

export default App;