import React from "react";
import "./../Styles/Stonegame.css";
import { Navigate } from "react-router-dom";

const actions = {
  0: "✊",
  1: "✌️",
  2: "🖐️",
};

class Stone extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      urChoice: "",
      compChoice: "",
      urScore: 0,
      compScore: 0,
      navigate: false,
      msg:'',
      win:''
    };
    this.choice = this.choice.bind(this); // Bind the method here
  }
  
  getWinner(player1, player2) {
    console.log("msg=>", player1, player2);
    if (player1 === player2) {
      return "It's a tie!";
    }

    if (
      (player1 === 0 && player2 === 1) || // Rock beats Scissors
      (player1 === 1 && player2 === 2) || // Scissors beats Paper
      (player1 === 2 && player2 === 0) // Paper beats Rock
    ) {
      return "Player 1 wins!";
    } else {
      return "Player 2 wins!";
    }
  }
  choice(e) {
    const { value } = e.target;

    this.setState((prev) => {
      const compValue = Math.floor(Math.random() * 3);
      const urChoice = parseInt(value);
      const compChoice = compValue;
      const result = this.getWinner(urChoice, compChoice);
      console.log("res=>", result);
      let urScore = prev.urScore;
      let compScore = prev.compScore;
      let msg,win ='';

      if (result === "Player 1 wins!") {
        urScore += 1;
        msg = 'Hurray! You Win!!'
        win='you'
      } else if (result === "Player 2 wins!") {
        compScore += 1;
        msg = 'OOPS! Computer Wins!!';
        win = 'comp'
      } else {
        msg = `It's a tie!`
        win = 'tie'
      }

      return {
        urChoice: actions[urChoice],
        compChoice: actions[compChoice],
        urScore,
        compScore,
        msg,
        win
      };
    });
  }
  handleNavigation = () => {
    this.setState({ navigate: true });
  };
  render() {
    const { navigate,msg ,win, urChoice, compChoice, urScore, compScore } = this.state;
    if (navigate) {
      return <Navigate to="/" />;
    }
    return (
      <div className="assign4">
        <div className="gameContainer">
          <div className="backBtn" onClick={this.handleNavigation}>
            Back
          </div>
          <h2 style={{color:'green'}}>WELCOME TO ROCK, PAPER, SCISSORS GAME</h2>
          <div className="choices">
            <button value="0" onClick={this.choice}>
            ✊ Rock
            </button>
            <button value="1" onClick={this.choice}>
            ✌️ Scissors
            </button>
            <button value="2" onClick={this.choice}>
            🖐️ Paper
            </button>
          </div>
          <div className="values">
            <p>Your Choice: {urChoice}</p>
            <p>Computer's Choice: {compChoice}</p>
            {msg.length>0 && <p className="result" style={{color:(win === 'you') ? 'green' : win === 'comp' ? 'red' : 'yellow'}}>{msg}</p>}
            <p>Yours Score: {urScore}</p>
            <p>Computer's Score: {compScore}</p>
          </div>
        </div>
      </div>
    );
  }
}

export default Stone;
