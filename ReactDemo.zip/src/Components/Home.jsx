import React from "react";
import { useNavigate } from "react-router";
import './../Styles/Home.css'

const Home = () => {
    let navigate = useNavigate();
    
return(
    <div className="home">
        <div className="react-header "> 
            <p>React Assignments</p>
        </div>
        <div className="assignDiv">
            <div className="assign" onClick={e=> navigate('/Assign1')}>Assign - 1</div>
            <div className="assign" onClick={e=> navigate('/Assign2')}>Assign - 2</div>
            <div className="assign" onClick={e=> navigate('/Assign3')}>Assign - 3</div>
            <div className="assign" onClick={e=> navigate('/Assign4')}>Assign - 4</div>
        </div>
    </div>
)
};

export default Home;