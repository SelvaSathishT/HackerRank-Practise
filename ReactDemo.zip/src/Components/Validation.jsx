import React, {useState, useEffect} from 'react';
import './../Styles/Validaion.css';
import { useNavigate } from "react-router";
import * as Validator from 'validatorjs';

const Validation = () => {
  const [text, setText] = useState('');
  const [isValid,setIsValid] = useState(false);
  const [errors, setErrors] = useState([]);
  let navigate = useNavigate();

  useEffect(() => {
    isStrongPassword();
  }, [text]);

  const rules = {
  password: [
    'required',
    'min:8',
    'regex:/[A-Z]/',
    'regex:/[a-z]/',
    'regex:/[0-9]/',
    'regex:/[!@#$%^&*(),.?":{}|<>]/',
  ]
};
  
  const isStrongPassword = () => {
    const validation = new Validator({password:text},rules);
    //console.log('valid=>',validation);
    if(validation.fails()){
      //console.log('failed=>',validation.errors.get('password'))
      setErrors(validation.errors.get('password'));
      setIsValid(false);
    } 
    if(validation.passes()){
      console.log('validation passed')
      setErrors([]);
      setIsValid(true);

    }
  }

  return (
    <div className="Validation">
      <div className="content">
      <div className="backBtn" onClick={e=>navigate(-1)}>Back</div>
        <h3>Checking Password Strength in ReactJS</h3><br/>
        <label>Enter Password:</label>
        <input type="text" value={text} onChange={e => setText(e.target.value)}/><br/>
        {/* <button onClick={isStrongPassword}>check</button> */}
        {isValid ? (
          <span style={{color:'green',marginTop:'3px'}}>Password is strong</span>
        ) : (
          <div>
            {errors.map((error, index) => (
              <p key={index} style={{color:'red',marginTop:'3px'}}>{error}</p>
            ))}
          </div>
        )}

      </div>
    </div>
  )
}

export default Validation