import React from "react";
import "./../Styles/Dicegame.css";
import { Navigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faDiceOne,
  faDiceTwo,
  faDiceThree,
  faDiceFour,
  faDiceFive,
  faDiceSix,
} from "@fortawesome/free-solid-svg-icons";

const sides = [
  <FontAwesomeIcon icon={faDiceOne} color="#675bc7" />,
  <FontAwesomeIcon icon={faDiceTwo} color="#675bc7" />,
  <FontAwesomeIcon icon={faDiceThree} color="#675bc7" />,
  <FontAwesomeIcon icon={faDiceFour} color="#675bc7" />,
  <FontAwesomeIcon icon={faDiceFive} color="#675bc7" />,
  <FontAwesomeIcon icon={faDiceSix} color="#675bc7" />,
];
class Die extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      length: 1,
      navigate: false,
      die1: sides[0],
      die2: sides[0],
      value: "",
      isRolling: false,
    };
  }
    
  addLength = () => {
    console.log("increasing length...");
    this.setState((prev) => ({
      length: prev.length + 1,
    }));
  };
  handleNavigation = () => {
    this.setState({ navigate: true });
  };
  roll = () => {
    this.setState(() => ({
      isRolling: true,
    }));

    setTimeout(() => {
      const value1 = Math.floor(Math.random() * sides.length);
      const value2 = Math.floor(Math.random() * sides.length);

      console.log("values=>", value1, value2);
      const total = value1 + 1 + (value2 + 1);
      this.setState((prev) => ({
        die1: sides[value1],
        die2: sides[value2],
        value: `The value rolled is ${total}`,
        isRolling:false
      }));
    }, 1000);
  };
  render() {
    const { navigate, die1, die2, value, isRolling } = this.state;

    if (navigate) {
      return <Navigate to="/" />;
    }
    const dieClassName = `diceImg ${isRolling ? 'diceImg-shaking' : ''}`;

    return (
      <div className="assign3">
        <div className="dice">
          <div className="backBtn" onClick={this.handleNavigation}>
            Back
          </div>
          <div className="dice-container">
            
            <h2>Dice Rolling</h2>
            <div className="die">
              
              <div className={dieClassName}>{die1}</div> 
              <div className={dieClassName}>{die2}</div> 
            </div>
            <div className="rollBtn" onClick={this.roll}>Roll Dice!</div>
          </div>
          {value.length > 0 && <p>{value}</p>}
        </div>
      </div>
    );
  }
}

export default Die;
