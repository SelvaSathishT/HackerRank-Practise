import React from "react";
import { useNavigate } from "react-router";

const Demo = () => {
    let navigate = useNavigate();
    
    
return(
    <div>
        <h1>Hi from demo page</h1><br/>
        <button >Click here to navigate</button>
    </div>
)
};

export default Demo;