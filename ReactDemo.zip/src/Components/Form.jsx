import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import "./../Styles/Form.css";

const Form = () => {
  let navigate = useNavigate();
  const initialValues = {
    firstName: '',
    lastName: '',
    email: '',
    contact: '',
    gender: '',
    subject: [],
    url: '',
    location: '',
    about: ''
  };
  const [formValue, setFormValue] = useState(initialValues);
  const [selectedFile, setSelectedFile] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [submittedValues, setSubmittedValues] = useState(null);

  const handleInputChange = (e)=>{
    const {name,value, type, checked} = e.target;
    console.log('onchange trigger...',name,value,type, checked)
    
    setFormValue(prev => ({
      ...prev,
      [name]:type === "checkbox" ? checked ? [...prev.subject,value] : prev.subject.filter(item => item !== value) : value
    }))
  };

  const handleFileChange = (e)=>{
    const {files} = e.target;
    console.log('files=>',e.target.files);
    setSelectedFile(files);
  }

  const validateForm = (values)=>{
    var errors= {}
    if(values.firstName == ''){
      errors.firstName="First name cannot be empty";
    } 
    if(values.lastName == ''){
      errors.lastName="Last name cannot be empty";
    } 
    if(values.email == '' || !values.email.includes('@')){
      errors.email="Enter the valid email"
    }
    if(values.contact == '' || isNaN(values.contact) || values.contact.length < 10){
      errors.contact="Enter valid Contact number";
    }
    if(values.url == '' || !values.url.includes('.')){
      errors.url="Enter valid URL";
    }
    if(!selectedFile){
      errors.file = "No File Selected"
    }
    return errors;
  }

  const handleSubmit = (e)=>{
    e.preventDefault();
    const errors = validateForm(formValue);

    if(Object.keys(errors).length > 0){
      alert(Object.values(errors).join('\n'));
      return;
    }
    console.log('formValue=>',selectedFile);
    setSubmittedValues(formValue)
    setShowResult(!showResult);
  }

  const handleReset = (e) => {
    e.preventDefault();
    setFormValue(initialValues);
    setSelectedFile(null);
  }

  const handleEdit = () => {
    setShowResult(false);
    setFormValue(submittedValues);
  }

  return (
    <div className="Assign1" style={{ gap: showResult? '12em': ''}}>
      <div className="formDiv">
        <div className="backBtn" onClick={e=>navigate(-1)}>Back</div>
        <center id="title">Form in React</center>
        <form>
          <label>First Name*</label>
          <br />
          <input
            type="text"
            className="textBox"
            placeholder="Enter First Name"
            name="firstName"
            value={formValue.firstName}
            onChange={handleInputChange}
            required
            disabled={showResult}
          />
          <br />
          <label>Last Name*</label>
          <br />
          <input
            type="text"
            className="textBox"
            placeholder="Enter Last Name"
            name="lastName"
            value={formValue.lastName}
            onChange={handleInputChange}
            disabled={showResult}
          />
          <br />
          <label>Enter Email*</label>
          <br />
          <input type="text" className="textBox" placeholder="Enter email" name="email"
            value={formValue.email}
            onChange={handleInputChange}
            disabled={showResult}/>
          <br />
          <label>Contact*</label>
          <br />
          <input type="number" className="textBox" placeholder="Enter Mobile number" name="contact"
            value={formValue.contact}
            onChange={handleInputChange}
            disabled={showResult}/>
          <br />
          <label>Gender</label>
          <br />
          <input type="radio" className="radioBox" value="Male" name="gender" checked={formValue.gender === "Male"} onChange={handleInputChange} disabled={showResult} />
          <label>Male</label>
          <input
            type="radio"
            className="radioBox"
            value="Female"
            name="gender"
            checked={formValue.gender === "Female"} onChange={handleInputChange}
            disabled={showResult}
          />
          <label>Female</label>
          <input
            type="radio"
            className="radioBox"
            value="Other"
            name="gender"
            checked={formValue.gender === "Other"} onChange={handleInputChange}
            disabled={showResult}
          />
          <label>Other</label>
          <br />
          <label>Your best Subject</label>
          <br />
          <input type="checkbox" className="checkBox" name="subject" checked={formValue.subject.includes("English")} onChange={handleInputChange} value="English" disabled={showResult} />
          <label>English</label>
          <input type="checkbox" className="checkBox" name="subject" checked={formValue.subject.includes("Maths")} onChange={handleInputChange} value="Maths" disabled={showResult} />
          <label>Maths</label>
          <input type="checkbox" className="checkBox" name="subject" checked={formValue.subject.includes("Physics")} onChange={handleInputChange} value="Physics" disabled={showResult} />
          <label>Physics</label>
          <br />
          <label>Upload Resume*</label>
          <br />
          <input
            type="file"
            className="textBox"
            placeholder="No File selected"
            onChange={handleFileChange}
            disabled={showResult}
          />
          <br />
          <label>Enter URL*</label>
          <br />
          <input type="text" className="textBox" placeholder="Enter url" name="url"
            value={formValue.url}
            onChange={handleInputChange}
            disabled={showResult}/>
          <br />
          <label>Select your location</label>
          <br />
          <select className="textBox" name="location"
            value={formValue.location}
            onChange={handleInputChange} disabled={showResult}>
            <option value="Select your location">Select your location</option>
            <option value="Chennai">Chennai</option>
            <option value="Bangalore">Bangalore</option>
          </select>
          <br />
          <label>About</label>
          <br />
          <textarea rows="2" cols="38" style={{fontSize: 'small'}} placeholder="About your self" name="about"
            value={formValue.about}
            onChange={handleInputChange} disabled={showResult}></textarea>
          <br />
          {!showResult && <><label>Submit OR Reset</label>
          <br />
          <button type="reset" className="button" onClick={handleReset}>Reset</button>
          <button type="submit" className="button" onClick={handleSubmit}>Submit</button>
          </>}
        </form>
      </div>
      {showResult && <div className="outputDiv">
        <center id="title">Output <span title="Edit" style={{cursor: 'pointer'}} onClick={handleEdit}>📝</span></center> 
        {Object.entries(submittedValues).map(([key,value],index)=> (
          <p key={index}><strong>{key}:</strong>    {value}</p>
        ))}
        <p><strong>Resume: </strong>{selectedFile ? selectedFile[0]?.name : '-'}</p>
      </div>}
    </div>
  );
};

export default Form;
