import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from './../Components/Home';
import Form from './../Components/Form';
import Validation from './../Components/Validation';
import Die from './../Components/Dicegame';
import Stone from "../Components/Stonegame";

const RoutesPage = () => {
    return (
        <Routes>
            {/* <Route path="/" element={<Form />} /> */}
            <Route path="/" element={<Home />} />
            <Route path="/Assign1" element={<Form />} />
            <Route path="/Assign2" element={<Validation />} />
            <Route path="/Assign3" element={<Die />} />
            <Route path="/Assign4" element={<Stone />} />
        </Routes>
    );
};

export default RoutesPage;