import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FlatModuleRoutingModule } from './flat-module-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    FlatModuleRoutingModule
  ]
})
export class FlatModuleModule { 
  constructor(){
    console.log('Flat module mounted...');
  }
}
