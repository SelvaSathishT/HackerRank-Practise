import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { FlatModuleModule } from './flat-module/flat-module.module';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //FlatModuleModule
  ],
  providers: [],
  bootstrap: [
    HomeComponent
  ]
})

export class AppModule {}
// export class AppModule implements DoBootstrap {
//   ngDoBootstrap(appRef: ApplicationRef): void {
//     const newElement = document.createElement('app-root');
//     document.body.appendChild(newElement);
//     appRef.bootstrap(AppComponent)
//   }
//  }
