import { Component, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {
  ngText = "Binding Concepts...";

  @ViewChild('button') buttonref!: ElementRef

  btnText = "Click here to insert Button";

  toggleBtn(){
    if(this.buttonref.nativeElement.innerHTML){
      this.btnText = "Click here to insert Button"
      this.buttonref.nativeElement.innerHTML= ''
    } else {
      this.btnText = "Click here to remove Button"
      this.buttonref.nativeElement.innerHTML = "<button>Button Added</button>";
    }
  }

  isChecked = false;
  output = "";

  handleChange(){
    this.isChecked = this.isChecked ? false : true
    if(this.isChecked){
      this.output = "Checkbox is Checked"
    } else {
      this.output = "Checkbox is unChecked";
    }
  }

  countValue = ""
  @ViewChild('home') homeRef!: ElementRef
  handleCount(){
    const element = this.homeRef.nativeElement;
    const tags = element.querySelectorAll('*');
    this.countValue = `HTML Tags Count = ${tags.length}`
  }
}
