import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';



@NgModule({
  declarations: [],
  imports: [
    //CommonModule,
    BrowserModule,
    
  ],
  bootstrap:[
    AppComponent
  ]
})
export class RootModuleModule {
  constructor(){
    console.log('Root module changed...')
  }
 }
