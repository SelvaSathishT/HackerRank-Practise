import { platformBrowser } from '@angular/platform-browser';
import { AppModule } from './app/app.module';
import { RootModuleModule } from './app/root-module.module';

// platformBrowser().bootstrapModule(RootModuleModule, {
//   ngZoneEventCoalescing: true,
// })
//   .catch(err => console.error(err));

  platformBrowser().bootstrapModule(AppModule, {
    ngZoneEventCoalescing: true,
  })
    .catch(err => console.error(err));
