import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainPageComponent } from './main-page/main-page.component';
import { AddFlightComponent } from './add-flight/add-flight.component';
import { ModifyFlightComponent } from './modify-flight/modify-flight.component';
import { DeleteFlightComponent } from './delete-flight/delete-flight.component';

const routes: Routes = [
  { path: '', component: MainPageComponent },
  { path: 'addFlight', component: AddFlightComponent },
  { path: 'modifyFlight', component: ModifyFlightComponent },
  { path: 'deleteFlight', component: DeleteFlightComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
