import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'AngularPOC';
  activeItem: string = 'View Flight';

  constructor(private router: Router) {}

  setActive(item: string) {
    this.activeItem = item;
    this.navigateToRoute(item);
  }

  navigateToRoute(item: string) {
    switch (item) {
      case 'View Flight':
        this.router.navigate(['/']);
        break;
      case 'Add Flight':
        this.router.navigate(['/addFlight']);
        break;
      case 'Modify Flight':
        this.router.navigate(['/modifyFlight']);
        break;
      case 'Delete Flight':
        this.router.navigate(['/deleteFlight']);
        break;
      default:
        this.router.navigate(['/']);
        break;
    }
  }
}
