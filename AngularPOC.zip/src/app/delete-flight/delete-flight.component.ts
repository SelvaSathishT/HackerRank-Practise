import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-delete-flight',
  standalone: false,
  templateUrl: './delete-flight.component.html',
  styleUrl: './delete-flight.component.css'
})
export class DeleteFlightComponent {
  url = `http://localhost:3000/airLines`;
  airlines: any[] = [];
  selectedAirline = {
    "id": "",
    "providerName": "",
    "providerCode": "",
    "providerType": ""
  };
  deleteCode = "";
  found: boolean = false;
  result: boolean = false;
  msg: string = 'No AirLine Found';

  constructor(
    private refHttpClient: HttpClient,
    private router: Router
  ) {  }

  ngOnInit() {
    this.fetchAirLines();
  }

  fetchAirLines() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.airlines = res;
      console.log(res);
    });
  }

  handleSearch(){
    console.log('delete code=>',this.deleteCode.toUpperCase());
    this.selectedAirline = this.airlines.find(a => a.providerCode === this.deleteCode.toUpperCase());
    if(this.selectedAirline){
      this.found = true;
      this.result = true;
      console.log('found =>',this.selectedAirline);
    } else {
      this.result = true;
      this.found = false;
    }
  }

  handleDelete(){
    const deleteId = this.selectedAirline.id;
    this.refHttpClient.delete(`${this.url}/${deleteId}`).subscribe((res)=>{
      console.log('Deleted Successfully...');
      this.router.navigate(['/']);
    })
  }
}
