import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';


@Component({
  selector: 'app-add-flight',
  standalone: false,
  templateUrl: './add-flight.component.html',
  styleUrl: './add-flight.component.css'
})
export class AddFlightComponent {
  url = `http://localhost:3000/airLines`;
  airlines: any[] = [];
  flightForm: FormGroup;
  formSubmitted: boolean = false;
  providerCodes = {
    INDIGO: '6E-',
    SPICEJET: 'SG-',
    'AIR ASIA': 'I5-',
    'GO AIR': 'G8-',
    'JET AIRWAYS': '9W-',
    'AIR INDIA': 'AI-',
  };

  constructor(
    private refHttpClient: HttpClient,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.flightForm = this.fb.group({
      providerName: ['', [Validators.required]],
      providerCode: ['', [Validators.required]],
      providerType: ['', [Validators.required]],
    });
  }

  ngOnInit() {
    this.fetchAirLines();
  }

  fetchAirLines() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.airlines = res;
      //console.log(res);
    });
  }

  handleNameChange(): void {
    const providerName = this.flightForm.value.providerName.toUpperCase();
    const providerCode =
      this.providerCodes[providerName as keyof typeof this.providerCodes] || '';
    this.flightForm.get('providerCode')?.setValue(providerCode);
    this.flightForm.value.providerCode = providerCode;
  }

  onSubmit() {
    this.formSubmitted = true;
    if (this.flightForm.valid) {
      const lastIndex = this.airlines[this.airlines.length - 1];
      console.log('form=>', this.flightForm.value, Number(lastIndex.id) + 1);

      const newFlight = {
        id: String(Number(lastIndex.id) + 1),
        providerName: this.flightForm.value.providerName,
        providerCode: this.flightForm.value.providerCode,
        providerType: this.flightForm.value.providerType,
      };

      this.refHttpClient.post<any>(this.url, newFlight).subscribe(
        (response) => {
          console.log('New flight added:', response); // Optionally, update the airlines list with the new flight
          this.router.navigate(['/']);
          this.flightForm.reset();
          this.formSubmitted = false;
        },
        (error) => {
          console.error('Error adding new flight:', error);
        }
      );
    }
  }
}
