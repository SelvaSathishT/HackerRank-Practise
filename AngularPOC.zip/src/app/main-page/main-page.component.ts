import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-main-page',
  standalone: false,
  templateUrl: './main-page.component.html',
  styleUrl: './main-page.component.css',
})
export class MainPageComponent {
  url = `http://localhost:3000/airLines`;
  airlines: any[] = [];
  filteredAirlines: any[] = [];
  displayedColumns: string[] = [
    'index',
    'providerName',
    'providerCode',
    'providerType',
  ];
  filterType: string = '';

  constructor(private refHttpClient: HttpClient) {}

  ngOnInit() {
    this.fetchAirLines();
  }

  fetchAirLines() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.airlines = res;
      this.applyFilter();
      //console.log(res);
    });
  }

  applyFilter() {
    if (this.filterType) {
      this.filteredAirlines = this.airlines.filter(
        (airline) => airline.providerType === this.filterType
      );
    } else {
      this.filteredAirlines = this.airlines;
    }
  }

  onFilterChange(event: any) {
    this.filterType = event.target.value;
    this.applyFilter();
  }
}
