import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-modify-flight',
  standalone: false,
  templateUrl: './modify-flight.component.html',
  styleUrl: './modify-flight.component.css'
})
export class ModifyFlightComponent {
  url = `http://localhost:3000/airLines`;
  airlines: any[] = [];
  selectedAirline = {
    "id": "",
    "providerName": "",
    "providerCode": "",
    "providerType": ""
  };
  newType ="";

  constructor(
    private refHttpClient: HttpClient,
    private router: Router
  ) {  }

  ngOnInit() {
    this.fetchAirLines();
  }

  fetchAirLines() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.airlines = res;
      //console.log(res);
    });
  }

  handleAirlineSelection(event : Event){
    const selectedId = (event.target as HTMLSelectElement).value;
    console.log(selectedId);
    this.selectedAirline = this.airlines.find(a => a.id === selectedId);
    console.log(this.selectedAirline);
  }

  handleTypeChange(event: Event){
    const type = (event.target as HTMLSelectElement).value;
    this.newType = type;
  }

  onModify(){
    
    if(this.newType === this.selectedAirline.providerType){
      console.log('no change')
    } else {
      console.log('changing...', `${this.url}/${this.selectedAirline.id}`)
      this.refHttpClient.patch(`${this.url}/${this.selectedAirline.id}`,{providerType: this.newType}).subscribe((res)=>{
        console.log('modified result=>',res);
        this.router.navigate(['/'])
        this.selectedAirline = {
          "id": "",
          "providerName": "",
          "providerCode": "",
          "providerType": ""
        };
        this.newType = "";
      })
    }
  }
}
