import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TodoCompComponent } from './todo-comp/todo-comp.component';
import { AppComponent } from './app.component';
import { MainPageComponent } from './main-page/main-page.component';
import { ECommerceComponent } from './e-commerce/e-commerce.component';
import { CartCommerceComponent } from './cart-commerce/cart-commerce.component';
import { BlogAppComponent } from './blog-app/blog-app.component';
import { AuthorProfileComponent } from './author-profile/author-profile.component';
import { LyricsCompComponent } from './lyrics-comp/lyrics-comp.component';
import { SinglePageCompComponent } from './single-page-comp/single-page-comp.component';
import { AudioPlayerComponent } from './audio-player/audio-player.component';
import { EventTimerComponent } from './event-timer/event-timer.component';

const routes: Routes = [
  {path: '', component: MainPageComponent},
  {path: 'todo', component: TodoCompComponent},
  {path: 'ecommerce', component: ECommerceComponent},
  {path:'ecommerce/cart', component: CartCommerceComponent},
  {path: 'blog', component: BlogAppComponent},
  {path: 'blog/author/:id',component: AuthorProfileComponent},
  {path: 'lyrics', component: LyricsCompComponent},
  {path: 'singlePage', component: SinglePageCompComponent},
  {path: 'audio', component: AudioPlayerComponent},
  {path: 'eventCount', component: EventTimerComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
