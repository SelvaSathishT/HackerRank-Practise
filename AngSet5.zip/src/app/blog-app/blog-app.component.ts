import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-app',
  standalone: false,
  templateUrl: './blog-app.component.html',
  styleUrl: './blog-app.component.css'
})
export class BlogAppComponent {
  selectedPage = "Articles";
}
