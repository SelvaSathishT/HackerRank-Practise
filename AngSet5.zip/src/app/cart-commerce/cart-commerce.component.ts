import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-cart-commerce',
  standalone: false,
  templateUrl: './cart-commerce.component.html',
  styleUrl: './cart-commerce.component.css',
})
export class CartCommerceComponent {
  cartItems: any[] = [];
  url = 'http://localhost:3000/cart';

  constructor(private refHttpClient: HttpClient, private location: Location) {}

  ngOnInit() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      console.log('cartItems=>', res);
      this.cartItems = res;
    });
  }

  handleBack() {
    this.location.back();
  }

  // handleCheckout(){
  //   console.log('checkout clicked',this.url)
  //   this.refHttpClient.delete(this.url).subscribe({
  //     next:(res)=>{
  //       alert('Product checkout successful')
  //     },
  //     error:(err)=>{
  //       console.log('error=>',err)
  //     }
  //   })
  // }

  handleCheckout() {
    console.log('checkout clicked', this.url);
    this.cartItems = [];
    alert('Product checkout successful');
    
  }
}
