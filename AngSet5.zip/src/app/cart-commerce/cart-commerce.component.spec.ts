import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CartCommerceComponent } from './cart-commerce.component';

describe('CartCommerceComponent', () => {
  let component: CartCommerceComponent;
  let fixture: ComponentFixture<CartCommerceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CartCommerceComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CartCommerceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
