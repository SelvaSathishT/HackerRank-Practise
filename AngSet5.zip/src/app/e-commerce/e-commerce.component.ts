import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-e-commerce',
  standalone: false,
  templateUrl: './e-commerce.component.html',
  styleUrl: './e-commerce.component.css'
})
export class ECommerceComponent {
  url = 'http://localhost:3000/clothes';
  products: any[] = [];
  filteredProducts: any[] = [];
  selectedSize: String ='All';

  constructor(private refHttpClient: HttpClient, private router:Router){ }

  ngOnInit(){
    this.refHttpClient.get<any[]>(this.url).subscribe((res)=>{
      console.log('products=>',res)
      this.products = res;
      this.filteredProducts = res;
    })
  }

  handleSize(event:Event){
    const size = (event.target as HTMLSelectElement).value;
    this.selectedSize = size;
    console.log('size=>',size);
    if(size === 'All'){
      this.filteredProducts = this.products
    } else {
      this.filteredProducts = this.products.filter(prod => prod.sizes.includes(size));
    }
  }

  addToCart(item:any){
    this.refHttpClient.post('http://localhost:3000/cart',item).subscribe((res)=>{
      alert('Product added')
    })
  }

  navigateToCart(){
    this.router.navigate([`/ecommerce/cart`])
  }
}
