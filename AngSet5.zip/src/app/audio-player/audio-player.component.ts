import { Component } from '@angular/core';

@Component({
  selector: 'app-audio-player',
  standalone: false,
  templateUrl: './audio-player.component.html',
  styleUrl: './audio-player.component.css',
})
export class AudioPlayerComponent {
  songs = [
    { name: 'Song 1', path: 'assets/Song1.mp3' },
    { name: 'Song 2', path: 'assets/Song2.mp3' },
    { name: 'Song 3', path: 'assets/Song3.mp3' },
    { name: 'Song 4', path: 'assets/Song4.mp3' },
  ];
  currentSongIndex: number = -1;
  currentSong: any = null;
  audio = new Audio();

  constructor() {}

  ngOnInit(): void {}

  selectSong(index: number) {
    this.currentSongIndex = index;
    this.currentSong = this.songs[index];
    this.play();
  }

  play() {
    if (this.currentSong) {
      this.audio.src = this.currentSong.path;
      this.audio.play();
    }
  }

  pause() {
    this.audio.pause();
  }

  stop() {
    this.audio.pause();
    this.audio.currentTime = 0;
  }

  previous() {
    if (this.currentSongIndex > 0) {
      this.selectSong(this.currentSongIndex - 1);
    }
  }

  next() {
    if (this.currentSongIndex < this.songs.length - 1) {
      this.selectSong(this.currentSongIndex + 1);
    }
  }
}
