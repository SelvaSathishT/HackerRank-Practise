import { Component } from '@angular/core';

@Component({
  selector: 'app-event-timer',
  standalone: false,
  templateUrl: './event-timer.component.html',
  styleUrl: './event-timer.component.css',
})
export class EventTimerComponent {
  timers: { title: string; category: string; timeInSeconds: number }[] = [];
  newTimer = { title: '', category: '', timeInSeconds: 0 };

  addTimer() {
    this.timers.push({ ...this.newTimer });
    this.newTimer = { title: '', category: '', timeInSeconds: 0 };
  }

  removeTimer(index: number) {
    this.timers.splice(index, 1);
  }
}
