import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-countdown-timer',
  standalone: false,
  templateUrl: './countdown-timer.component.html',
  styleUrl: './countdown-timer.component.css',
})
export class CountdownTimerComponent {
  @Input() title: string = '';
  @Input() category: string = '';
  @Input() timeInSeconds: number = 0;

  remainingTime: string = '';
  isRunning: boolean = true;

  ngOnInit() {
    this.startTimer();
  }

  startTimer() {
    const interval = setInterval(() => {
      if (this.timeInSeconds <= 0) {
        this.isRunning = false;
        clearInterval(interval);
      } else {
        this.timeInSeconds--;
        this.remainingTime = this.formatTime(this.timeInSeconds);
      }
    }, 1000);
  }

  formatTime(seconds: number): string {
    const days = Math.floor(seconds / (3600 * 24));
    const hours = Math.floor((seconds % (3600 * 24)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
  }
}
