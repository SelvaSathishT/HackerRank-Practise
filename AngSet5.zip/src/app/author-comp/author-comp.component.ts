import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-author-comp',
  standalone: false,
  templateUrl: './author-comp.component.html',
  styleUrl: './author-comp.component.css'
})
export class AuthorCompComponent {
  url ='http://localhost:3000/authors';
  authors: any[]=[];

  constructor(private refHttpClient : HttpClient, private router : Router){ }

  ngOnInit(){
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.authors = res;
    });
  }

  navigateAuthor(id:string){
    this.router.navigate([`/blog/author/${id}`]);
  }
}
