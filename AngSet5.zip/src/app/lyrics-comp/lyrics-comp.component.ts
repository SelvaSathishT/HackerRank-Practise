import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-lyrics-comp',
  standalone: false,
  templateUrl: './lyrics-comp.component.html',
  styleUrl: './lyrics-comp.component.css'
})
export class LyricsCompComponent {
  url = `https://api.lyrics.ovh/v1`;
  submitted:boolean = false;
  lyrics = '';
  formGroup: FormGroup;

  constructor(private fb:FormBuilder , private refHttpClient: HttpClient){
    this.formGroup = this.fb.group({
      artist: ['', Validators.required],
      song: ['',Validators.required]
    })
  }

  handleSearch(){
    this.submitted = true;
    if(this.formGroup.valid){
      console.log(this.formGroup.value.artist, this.formGroup.value.song);
      this.refHttpClient.get<{lyrics: string}>(`${this.url}/${this.formGroup.value.artist}/${this.formGroup.value.song}`).subscribe({
        next:(res)=>{
          console.log('lyrics=>',res);
          this.lyrics = res.lyrics.replace(/\n/g, '<br/>');
        },
        error:(err)=>{
          console.log('error=>',err);
          this.lyrics = 'No Lyrics Found'
        }
      })
    }
  }
}
