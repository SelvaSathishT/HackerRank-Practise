import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LyricsCompComponent } from './lyrics-comp.component';

describe('LyricsCompComponent', () => {
  let component: LyricsCompComponent;
  let fixture: ComponentFixture<LyricsCompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LyricsCompComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LyricsCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
