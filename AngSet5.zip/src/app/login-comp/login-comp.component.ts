import { Component } from '@angular/core';

@Component({
  selector: 'app-login-comp',
  standalone: false,
  templateUrl: './login-comp.component.html',
  styleUrl: './login-comp.component.css'
})
export class LoginCompComponent {

}
