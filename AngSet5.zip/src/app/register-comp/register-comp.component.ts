import { Component } from '@angular/core';

@Component({
  selector: 'app-register-comp',
  standalone: false,
  templateUrl: './register-comp.component.html',
  styleUrl: './register-comp.component.css'
})
export class RegisterCompComponent {

}
