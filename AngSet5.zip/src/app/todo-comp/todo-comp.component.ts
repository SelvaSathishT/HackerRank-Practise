import { HttpClient } from '@angular/common/http';
import { Component, TemplateRef, ViewChild } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-todo-comp',
  standalone: false,
  templateUrl: './todo-comp.component.html',
  styleUrl: './todo-comp.component.css',
})
export class TodoCompComponent {
  url = `http://localhost:3000/tasks`;
  allTasks: any[] = [];
  filteredTasks: any[] = [];
  selectedFilter: string = 'all';

  displayedColumns: string[] = ['index', 'taskname', 'status'];
  @ViewChild('addDialog') addDialog!: TemplateRef<any>;
  @ViewChild('editDialog') editDialog!: TemplateRef<any>;
  selectedTask: any = {};
  form: FormGroup;
  formSubmitted = false;
  dialogRef!: MatDialogRef<any>;
  newStatus: String = '';
  constructor(
    private refHttpClient: HttpClient,
    private refAddDialog: MatDialog,
    private fb: FormBuilder
  ) {
    this.form = this.fb.group({
      taskname: ['', Validators.required],
    });
  }

  ngOnInit() {
    this.fetchAlltasks();
  }

  fetchAlltasks() {
    this.refHttpClient.get<any[]>(this.url).subscribe((data) => {
      console.log('tasks=>', data);
      this.allTasks = data;
      this.filteredTasks = data;
    });
  }

  handleFilter(status: string) {
    //console.log('filtering Tasks =>',status);
    this.selectedFilter = status;
    if (status !== 'all') {
      this.filteredTasks = this.allTasks.filter(
        (task) => task.status === status
      );
    } else {
      this.filteredTasks = this.allTasks;
    }
  }

  // Append() {
  //   const newTask = { id: '4', taskname: 'Monday Routine', status: 'Pending' };

  //   this.refHttpClient
  //     .post(this.url, newTask)
  //     .subscribe((res) => console.log('response=>', res));
  // }

  // delete() {
  //   this.refHttpClient
  //     .delete(`${this.url}/4`)
  //     .subscribe((res) => console.log('delete res=>', res));
  // }

  openDialog(templateref: TemplateRef<any>) {
    //this.refAddDialog.open(templateref);
    this.dialogRef = this.refAddDialog.open(templateref);
    this.dialogRef.afterClosed().subscribe(() => {
      this.form.reset(); // Reset the form values
      this.formSubmitted = false; // Reset form submission state
    });
  }

  closeDialog() {
    this.dialogRef.close();
  }

  handleAdd() {
    this.formSubmitted = true;
    if (this.form.valid) {
      //console.log('taskname =>', this.form.value.taskname);

      const maxId = Math.max(
        ...this.allTasks.map((task) => parseInt(task.id, 10))
      );
      const newTask = {
        id: (maxId + 1).toString(),
        taskname: this.form.value.taskname,
        status: 'Pending',
      };
      //console.log('new task=> ', newTask);
      this.refHttpClient.post(this.url, newTask).subscribe((res) => {
        //console.log('response=>', res);
        this.fetchAlltasks(); // Refresh the task list
      });
      this.dialogRef.close(); // Close the dialog after adding the task
    }
  }

  openEditDialog(task: any) {
    this.dialogRef = this.refAddDialog.open(this.editDialog);
    this.selectedTask = task;
    this.newStatus = task.status;
    //console.log('selected task',this.selectedTask);
  }

  updateStatus(status: String) {
    this.newStatus = status;
  }

  handleEditCancel() {
    this.closeDialog();
    this.newStatus = '';
  }

  handleUpdate() {
    //console.log('task id',this.selectedTask.taskname,'new status:',this.newStatus);
    if (this.newStatus) {
      const updatedTask = { ...this.selectedTask, status: this.newStatus };
      this.refHttpClient
        .put(`${this.url}/${this.selectedTask.id}`, updatedTask)
        .subscribe((res) => {
          this.fetchAlltasks();
        });
    }
    this.handleEditCancel();
  }
}
