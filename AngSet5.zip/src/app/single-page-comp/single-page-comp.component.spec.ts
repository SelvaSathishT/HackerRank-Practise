import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SinglePageCompComponent } from './single-page-comp.component';

describe('SinglePageCompComponent', () => {
  let component: SinglePageCompComponent;
  let fixture: ComponentFixture<SinglePageCompComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SinglePageCompComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SinglePageCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
