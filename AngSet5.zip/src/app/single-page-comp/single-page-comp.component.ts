import { Component } from '@angular/core';

@Component({
  selector: 'app-single-page-comp',
  standalone: false,
  templateUrl: './single-page-comp.component.html',
  styleUrl: './single-page-comp.component.css'
})
export class SinglePageCompComponent {
  selectedPage:string ='login';

  handlePage(page:string){
    this.selectedPage = page;
    console.log(page);
  }
}
