import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TodoCompComponent } from './todo-comp/todo-comp.component';
import { provideHttpClient } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ECommerceComponent } from './e-commerce/e-commerce.component';
import { MainPageComponent } from './main-page/main-page.component';
import { CartCommerceComponent } from './cart-commerce/cart-commerce.component';
import { AuthorCompComponent } from './author-comp/author-comp.component';
import { BlogAppComponent } from './blog-app/blog-app.component';
import { ArticlesCompComponent } from './articles-comp/articles-comp.component';
import { AuthorProfileComponent } from './author-profile/author-profile.component';
import { LyricsCompComponent } from './lyrics-comp/lyrics-comp.component';
import { LoginCompComponent } from './login-comp/login-comp.component';
import { SinglePageCompComponent } from './single-page-comp/single-page-comp.component';
import { RegisterCompComponent } from './register-comp/register-comp.component';
import { ProfileCompComponent } from './profile-comp/profile-comp.component';
import { AudioPlayerComponent } from './audio-player/audio-player.component';
import { EventTimerComponent } from './event-timer/event-timer.component';
import { CountdownTimerComponent } from './countdown-timer/countdown-timer.component';


@NgModule({
  declarations: [
    AppComponent,
    TodoCompComponent,
    ECommerceComponent,
    MainPageComponent,
    CartCommerceComponent,
    AuthorCompComponent,
    BlogAppComponent,
    ArticlesCompComponent,
    AuthorProfileComponent,
    LyricsCompComponent,
    LoginCompComponent,
    SinglePageCompComponent,
    RegisterCompComponent,
    ProfileCompComponent,
    AudioPlayerComponent,
    EventTimerComponent,
    CountdownTimerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatTableModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    provideHttpClient()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
