import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-author-profile',
  standalone: false,
  templateUrl: './author-profile.component.html',
  styleUrl: './author-profile.component.css'
})
export class AuthorProfileComponent implements OnInit {
  url = 'http://localhost:3000/authors'
  authorId: string ='';
  author = {
    id:'',
    name: '',
    articles_written: ''
  };

  constructor(private route: ActivatedRoute, private refHttpClient: HttpClient){}

  ngOnInit():void{
    this.route.paramMap.subscribe(params => {
      const id =  params.get('id') || '';
      this.authorId = id;
      console.log('id',this.authorId);
      this.refHttpClient.get<any>(`${this.url}/${this.authorId}`).subscribe((res)=>{
        this.author = res;
        console.log(`${this.url}/${this.authorId}`,res);
      })
    })
  }
}
