import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-comp',
  standalone: false,
  templateUrl: './profile-comp.component.html',
  styleUrl: './profile-comp.component.css'
})
export class ProfileCompComponent {

}
