import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-articles-comp',
  standalone: false,
  templateUrl: './articles-comp.component.html',
  styleUrl: './articles-comp.component.css',
})
export class ArticlesCompComponent {
  url = 'http://localhost:3000/articles';
  articles: any[] = [];
  sortedArticles: any[] = [];
  sort ='';

  constructor(private refHttpClient: HttpClient) {}

  ngOnInit() {
    this.refHttpClient.get<any[]>(this.url).subscribe((res) => {
      this.articles = res;
      this.sortedArticles = res;
    });
  }

  handleSort(type: string) {
    console.log(type);
    this.sort = type;
    if (type === 'like') {
      this.sortedArticles.sort((a, b) => b.likes - a.likes);
    } else if (type === 'comment') {
      this.sortedArticles.sort((a, b) => b.comment_count - a.comment_count);
    }
  }
}
