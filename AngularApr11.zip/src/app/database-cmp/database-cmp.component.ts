import { Component } from '@angular/core';

@Component({
  selector: 'app-database-cmp',
  standalone: false,
  templateUrl: './database-cmp.component.html',
  styleUrl: './database-cmp.component.css'
})
export class DatabaseCmpComponent {

}
