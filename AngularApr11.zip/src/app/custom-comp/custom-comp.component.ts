import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-custom-comp',
  standalone: false,
  templateUrl: './custom-comp.component.html',
  styleUrl: './custom-comp.component.css'
})
export class CustomCompComponent {
  @Input() month: string = 'April';
}
