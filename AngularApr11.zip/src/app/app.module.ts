import { ApplicationRef, DoBootstrap, NgModule, Injector } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';
import {createCustomElement} from '@angular/elements';
import { FormsModule } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DatabaseCmpComponent } from './database-cmp/database-cmp.component';
import { UiToolsComponent } from './ui-tools/ui-tools.component';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { CricketTeamComponent } from './cricket-team/cricket-team.component';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { CustomCompComponent } from './custom-comp/custom-comp.component';
import { HighlightDirective } from './highlight.directive';
import { ReversePipe } from './reverse.pipe';


@NgModule({
  declarations: [
    AppComponent,
    DatabaseCmpComponent,
    UiToolsComponent,
    CricketTeamComponent,
    CustomCompComponent,
    HighlightDirective,
    ReversePipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ScrollingModule,
    DragDropModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }

// export class AppModule implements DoBootstrap{

//   constructor(private injector: Injector) {}

//   ngDoBootstrap(appRef: ApplicationRef): void {
//     const customEl = createCustomElement(CustomCompComponent, {injector: this.injector});
//     customElements.define('my-custom', customEl);
//     appRef.bootstrap(AppComponent);
//   }

//   // //1st Question
//   // ngDoBootstrap(appRef: ApplicationRef): void {

//   //   const runtime: string = 'UIComp';

//   //   if(runtime === 'DBComp') {
//   //     console.log("Bootstrapping DatabaseCmp Component");
//   //     appRef.bootstrap(DatabaseCmpComponent);
//   //   }
//   //   else {
//   //     console.log("Bootstrapping UITools Component");
//   //     appRef.bootstrap(UiToolsComponent);
//   //   }
//   // }
//  }
