import { Component } from '@angular/core';
import { CdkDragDrop, moveItemInArray } from '@angular/cdk/drag-drop';

@Component({
  selector: 'app-cricket-team',
  standalone: false,
  templateUrl: './cricket-team.component.html',
  styleUrl: './cricket-team.component.css'
})
export class CricketTeamComponent {
  players: string[] = [
    'Virat Kohli', 'Yuvraj Singh', 'Jasprit Bumrah',  'Shreyas Iyer', 'Md. Shami', 
    'Shubman Gill', 'KL Rahul', 'Hardik Pandya', 'Ravindra Jadeja', 'MS Dhoni'
  ];
 
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.players, event.previousIndex, event.currentIndex);
  }
}
