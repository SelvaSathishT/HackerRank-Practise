import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  // title = 'AngularApr11';

  // aiNumbers: number[] = [];
  // ngOnInit() {
  //   this.aiNumbers = Array.from({ length: 10001}, (_, i) => i); // 0 to 10000
  // }

  color: string = '';

  trainingList = [
    { TrainingRequestNo: 101, TrainingName: 'Flutter', TrainingMode: 'Online', Duration: '3 days' },
    { TrainingRequestNo: 102, TrainingName: 'Angular', TrainingMode: 'Offline', Duration: '5 days' },
    { TrainingRequestNo: 103, TrainingName: 'React', TrainingMode: 'Online', Duration: '4 days' }
  ];
 
  get sortedTrainingList() {
    return this.trainingList.sort((a, b) => a.TrainingName.localeCompare(b.TrainingName));
  }

  trainingMessage!: Promise<string>;

  constructor() {
    this.trainingMessage = new Promise(resolve => {
      setTimeout(() => {
        resolve('Content loaded after 2 seconds!');
      }, 2000);
    });
  }
}
