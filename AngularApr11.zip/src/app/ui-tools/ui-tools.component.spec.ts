import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UiToolsComponent } from './ui-tools.component';

describe('UiToolsComponent', () => {
  let component: UiToolsComponent;
  let fixture: ComponentFixture<UiToolsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [UiToolsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UiToolsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
