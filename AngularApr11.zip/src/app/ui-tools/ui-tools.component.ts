import { Component } from '@angular/core';

@Component({
  selector: 'app-ui-tools',
  standalone: false,
  templateUrl: './ui-tools.component.html',
  styleUrl: './ui-tools.component.css'
})
export class UiToolsComponent {

}
